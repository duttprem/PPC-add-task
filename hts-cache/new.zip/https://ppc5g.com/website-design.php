<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PPC 5G</title>
    <link rel="icon" type="image/x-icon" href="images/ppclogo.png">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" >
    <link href="css/swiper-bundle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-side-modals.css">
    <link rel="stylesheet" href="css/style.css" type="text/css"/>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N79T3LBF');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N79T3LBF"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->    <div class="progress-container">
        <div class="progress-bar" id="myBar"></div>
    </div>  
    <header class="lightbrowm">
        <div class="container">
            <div class="row">
                <div class="col-sm-2 logo">
                    <a href="index.php"><img src="images/ppclogo.png" /></a>
                </div>
                <div class="col-lg-6 col-md-9 col-sm-9">
                    <h1>Welcome to PPC5G.com</h1>
                    <p>Web5G Technology Pvt Ltd Redefines Success with Unmatched Google Ads & Advanced Tracking Mastery, with a strong presence in Delhi NCR.</p>
                </div>
                <div class="col-sm-12 col-lg-4 col-md-12">
                    <ul>
                        <li><a href="tel:9999123123"> <img alt="" src="images/phone.png" height="20px" width="20px"> 9999-123-123 (Info)</a></li>
                        <li><a href="tel:8588001122"><img alt="" src="images/phone.png" height="20px" width="20px"> 8588-001122 (PPC Support)</a></li>
                        <li><a href="tel:7777909090"><img alt="" src="images/phone.png" height="20px" width="20px"> 7777-909090 (Audit & Consultancy)</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>
    <div class="menu">
    <div class="container">
        <ul class="menulist ">
            <li><a href="javascript:void(0);" class="menuicon" id="menushow"><i class="fa fa-bars" aria-hidden="true"></i> Menu</a></li>
        </ul>
        <a class="homeicon" href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a>
        <ul class="firstmenu fixbdr" id="nav-serialscrolling">
            <li><a href="#" data-serialscrolling="pagetype">Page Type</a></li>
            <li><a href="#" data-serialscrolling="prices">Prices</a></li>
            <li><a href="#" data-serialscrolling="technologies">Technologies</a></li>
            <li><a href="#" data-serialscrolling="mistakes">Mistakes</a></li>
            <li><a href="#" data-serialscrolling="integration">Integration</a></li>
        </ul>
        <div class="clearfix"></div>
    </div>
    <div class="menu childmenu">
        <div class="container">
            <ul class="firstmenu">
                <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal11">Why Us</a></li>
                <li><a href="#bookaduit" class="openModalBtn" data-modal-target="modal17">Pacakge</a></li>
                <li><a href="javascript:void(0);" class="menudropdown">Checklist <i class="fa fa-angle-down" aria-hidden="true"></i></a> 
                    <ul class="submenu open1">                        
                        <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal13"><i class="fa fa-angle-right" aria-hidden="true"></i> Web Pages Name List</a></li>
                        <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal14"><i class="fa fa-angle-right" aria-hidden="true"></i> Web Designing Categories</a></li>
                        <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal15"><i class="fa fa-angle-right" aria-hidden="true"></i> Clicklist of Website Features</a></li>
                        <li><a href="javascript:void(0);" id="more10"><i class="fa fa-angle-right" aria-hidden="true"></i> Website Integration Features</a></li>
                    </ul>
                </li>
            </ul>
            <div class="clearfix"></div>
        </div>
    </div>   
</div>
   
       <main>
        <section class="bgcontent">
            <div class="container">
                <h1>#1 WEBSITE EXPERTS</h1>
                <h4>Top-Ranked Website Designing Professionals in Delhi NCR</h4>
                <p>Choose your handpicked package options with custom features checklist, priorities and action plan.</p>
            </div>
        </section>
        <section class="pad20 lightbrowm sectionone">
            <div class="container">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="box_inner">
                                <h2>Why Choose Us for Website Design</h2>
                                <div class="swiper mySwiper">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <ul>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Transparent and welcome written agreement for all work-related aspects.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Extensive portfolio showcasing a history of successful projects.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Exclusive Reasons Why Clients Love Us. Here's Why <a href="javascript:void(0);" id="more"><i class="fa fa-question-circle-o" aria-hidden="true"></i></a></li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Ability to work within specified budgets and deliver cost-effective design solutions without compromising quality.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Check out the wide range of "Web-Designing" categories! See Here <a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal14"><i class="fa fa-question-circle-o" aria-hidden="true"></i></a></li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Additional Services That Provide Extra Value. <a href="javascript:void(0);" id="more2"><i class="fa fa-question-circle-o" aria-hidden="true"></i></a></li>
                                            </ul>
                                        </div>
                                        <div class="swiper-slide">
                                            <ul>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Easy selection process by designer themes and features/functionality checklist.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Expertise in finding cost-saving alternatives while ensuring clients' choices are respected.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Complete transparency in our pricing structure and cost breakdowns, ensuring no hidden fees or surprises.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Extensive experience in the industry, backed by years of successful projects.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Commitment to exceptional customer service, ensuring client satisfaction at every step.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Proven track record of completing projects on time and within budget.</li>
                                            </ul>
                                        </div>
                                        <div class="swiper-slide">
                                            <ul>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> In-house team of skilled web designers with a proven track record.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> In-depth understanding of client needs and goals for tailored website designs.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Capability to handle complex and large-scale projects with efficiency and professionalism. <a href="#"></a></li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Ability to handle projects of all sizes and complexities.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Vast knowledge of the latest trends and industry best practices in website design</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Valuing long-term partnerships, providing continuous support and advice.</li>                                                
                                            </ul>
                                        </div> 
                                        <div class="swiper-slide">
                                            <ul>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Documentation of all project details and discussions through written communication or email.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Strong reputation and positive client testimonials, showcasing our commitment to excellence.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Availability of post-project support and maintenance services to ensure long-term satisfaction.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Transparent cost breakdowns to help clients understand and control their expenses.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Recommendations for cost-effective hosting and domain registration solutions on a long term basis.</li>                                               
                                            </ul>
                                        </div>
                                        <div class="swiper-slide">
                                            <ul>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Long-term partnership approach with affordable maintenance provision to ensure long-term cost-efficiency.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Customization of website designs to meet the specific requirements of each client.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Responsive web design that ensures optimal performance on various devices and screen sizes.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Regular website maintenance and updates to ensure smooth operation.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Collaboration with clients throughout the design and decision-making process to meet their expectations.</li>
                                            </ul>
                                        </div>
                                        <div class="swiper-slide">
                                            <ul>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Open and honest communication regarding project timelines, updates, and any potential delays.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Willingness to share references and past client testimonials, allowing you to assess our track record and client satisfaction.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Openness about our team's qualifications, expertise, and experience, providing you with a clear understanding of our capabilities.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Willingness to take responsibility for our mistakes and work towards finding solutions.</li>
                                                <li><i class="fa Personalizfa-check" aria-hidden="true"></i> Personalized  approach to design, tailoring solutions to meet each client's unique needs and preferences.</li>
                                            </ul>
                                        </div>                                   
                                    </div>
                                    <div class="swiper-button-next"></div>
                                    <div class="swiper-button-prev"></div>
                                    <div class="swiper-pagination"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 text-center">
                            <div class="package_wrap">
                            <h3>Get Our Latest Offer</h3>
                                <span class="package_price">
                                <i class="fa fa-rupee"></i> <del>6,000</del> <i class="fa fa-rupee"></i></sup>4,800
                                </span>
                                <ul class="package_offers">
                                    <li>Upto 5 Pages</li>
                                    <li>Domain + Hosting</li>
                                    <li>Logo + Content + Graphic</li>
                                    <li>Inquiry Forms + Webmail ID</li>
                                    <li>Button - Enquiry</li>
                                    <li>In-Office Visit Allowed</li>
                                    <li>Video Production - Not Included</li>
                                </ul>
                                <div class="btn_group packageoffer">
                                    <p class="blinkNotification">Limited Time Offer ( Save <span class="blinking">25%</span>)</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="box_inner ">
                                <h2>LET US CONTACT YOU</h2>
                                <div class="details_form ">
                                    <form action="https://website5g.com/ppcmail.php" method="post" id="form1">
                                        <label>Enter Your Name <span style="color:red;">*</span></label>
                                        <div class="input-group mb-2">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><img src="images/user.png" alt="" /></span>
                                            </div>
                                            <input type="text" class="form-control" placeholder="Enter Your Name" name="name" required>
                                        </div>
                                        <label>Enter Your Email <span style="color:red;">*</span></label>
                                        <div class="input-group mb-2">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" ><img src="images/email.png" alt="" /></span>
                                            </div>
                                            <input type="email" name="email"  class="form-control" placeholder="Enter Your Email" required>
                                        </div>
                                        <label>Enter Your Number <span style="color:red;">*</span></label>
                                        <div class="input-group mb-2">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" ><img src="images/india-flag.png" alt="" /> &nbsp; +91</span>
                                            </div>
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel1" size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel2"  size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel3"  size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel4"  size="1" required >
                                            <input class="inputs one form-control mr1" type="tel" maxlength="1" placeholder="x"  name="tel5"  size="1" required >
                                            <input class="inputs one form-control ml1" type="tel" maxlength="1" placeholder="x"  name="tel6"  size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel7"  size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel8"  size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel9"  size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel10"  size="1" required >
                                        </div>
                                        <label>Enter Your City <span style="color:red;">*</span></label>
                                        <div class="input-group mb-2">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><img src="images/map.png" alt="" /></span>
                                            </div>
                                            <input type="text" name="city" class="form-control" placeholder="Enter Your City" required>
                                        </div>
                                        <label>Enquiry About (Optional)</label>
                                        <div class="input-group mb-2">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><img src="images/enquiry.png" alt="" /></span>
                                            </div>
                                            <input type="text" name="message" class="form-control" placeholder="Enter your Enquiry">
                                        </div>
                                        <input type="submit" name="submit" class="form-control mb-2 btn btn-primary" value="Submit &amp; Get A Call Back ">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
        <div class="gapmob"></div>
        <section class="about_us lightbrowm pkgde"  data-serialscrolling-target="pagetype">
            <div class="container">
                <h2 class="main_heading">Page Categories We Handle</h2>
                <p class="text-center">The Process of Identifying Types of Pages We Deal With in Website Design</p>
                <div class="provider_design mt-2">
                    <table class="table-striped w-100">
                        <tbody><tr>
                            <th style="width:60%;background:#434242;" class="">Package Type</th>
                            <th style="width:13.3%" class="purple">Trial</th>
                            <th style="width:13.3%" class="green">Pro</th>
                            <th style="width:13.3%" class="brown">Pro+</th>
                        </tr>
                    </tbody></table>
                    <div id="tableprovider">
                        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseads" aria-expanded="true" aria-controls="collapseads">
                            <b>Main Navigation &nbsp;<i class="fa fa-plus-circle"></i></b>
                        </button>
                        <div class="collapse show" id="collapseads" style="">
                            <div class="table-responsive">
                                <table class="table-striped w-100">
                                    <tbody>
                                    <tr>
                                        <td style="width:60%">Home Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">About Us Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Products/Services Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Pricing Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Checkout Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">My Account Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>                                   
                                </tbody></table>
                            </div>
                        </div>
                        <button class="btn btn-primary collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseadsone" aria-expanded="false" aria-controls="collapseadsone">
                            <b> Credibility and Trust <i class="fa fa-plus-circle"></i></b>
                        </button>
                        <div class="collapse" id="collapseadsone">
                            <div class="table-responsive">
                                <table class="table-striped w-100">
                                    <tbody>
                                    <tr>
                                        <td style="width:60%">Testimonials Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Press Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Awards/Accolades Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Success Stories</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Company History Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Investor Relations Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Partnerships Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Press Releases Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>    
                        </div>   
                        <button class="btn btn-primary collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseadsthree" aria-expanded="false" aria-controls="collapseadsthree">
                            <b> Customer Support <i class="fa fa-plus-circle"></i></b>
                        </button>
                        <div class="collapse" id="collapseadsthree">
                            <div class="table-responsive">
                                <table class="table-striped w-100">
                                    <tbody>
                                    <tr>
                                        <td style="width:60%">FAQ Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Contact Us Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Knowledge Base/Help Center</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Support Tickets</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Help Desk/Support Center Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Live Chat/Support Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Troubleshooting Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Setup/Installation Guides Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Maintenance Tips Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Customer Feedback Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Order Tracking Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>    
                        </div>     
                        <button class="btn btn-primary collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseadsfour" aria-expanded="false" aria-controls="collapseadsfour">
                            <b> Engagement and Interaction <i class="fa fa-plus-circle"></i></b>
                        </button>
                        <div class="collapse" id="collapseadsfour">
                            <div class="table-responsive">
                                <table class="table-striped w-100">
                                    <tbody>
                                    <tr>
                                        <td style="width:60%">Blog Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Events Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Community/Forum</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Podcast Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Video Library Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Webinars Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Community Guidelines Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Community Events Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Social Media Links/Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Newsletter/Updates Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Feedback/Suggestions Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>    
                        </div>
                        <button class="btn btn-primary collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseadsfive" aria-expanded="false" aria-controls="collapseadsfive">
                            <b> Legal and Policy  <i class="fa fa-plus-circle"></i></b>
                        </button>
                        <div class="collapse" id="collapseadsfive">
                            <div class="table-responsive">
                                <table class="table-striped w-100">
                                    <tbody>
                                    <tr>
                                        <td style="width:60%">Privacy Policy Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Terms and Conditions Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Returns/Refunds Policy Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Accessibility Statement Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">User Agreement Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Shipping Information Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Security Practices Pager</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Copyright Information Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>    
                        </div>   
                        <button class="btn btn-primary collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseadssix" aria-expanded="false" aria-controls="collapseadssix">
                            <b> Resources and Information <i class="fa fa-plus-circle"></i></b>
                        </button>
                        <div class="collapse" id="collapseadssix">
                            <div class="table-responsive">
                                <table class="table-striped w-100">
                                    <tbody>
                                    <tr>
                                        <td style="width:60%">Portfolio/Gallery</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Team/Staff</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Case Studies</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Research/Reports Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Whitepapers Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Trends/Insights Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Knowledge Base/Documentation Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Products/Services Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Features Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Product Comparison Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">API Documentation Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Integration Partners Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                            </div>    
                        </div> 
                        <button class="btn btn-primary collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseadsseven" aria-expanded="false" aria-controls="collapseadsseven">
                            <b>Special Features <i class="fa fa-plus-circle"></i></b>
                        </button>
                        <div class="collapse" id="collapseadsseven">
                            <div class="table-responsive">
                                <table class="table-striped w-100">
                                    <tbody>
                                    <tr>
                                        <td style="width:60%">Accessibility Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Sitemap Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Thank You Pages</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">404 Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Client Portal</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Partnerships/Affiliates</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">User Dashboard Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Cart Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Wishlist Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Store Locator Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Local Store Locator Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Store Policies Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Affiliate Program Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Referral Program Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Roadmap/Future Plans Page</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>                                    
                                </tbody>
                            </table>
                            </div>    
                        </div> 
                        <button class="btn btn-primary collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseadseight" aria-expanded="false" aria-controls="collapseadseight">
                            <b>Additional Pages <i class="fa fa-plus-circle"></i></b>
                        </button>
                        <div class="collapse" id="collapseadseight">
                            <div class="table-responsive">
                                <table class="table-striped w-100">
                                    <tbody>
                                    <tr>
                                        <td style="width:60%">Knowledge Base/Help Center</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Client Login/Member Area</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Download Centre</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Pricing Comparison</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Documentation/Manuals</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Interactive Tools/Calculators</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Press Kit/Media Resources</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Success Stories/Client Showcase</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Company Culture/Values</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Company Blog/Newsroom</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Social Responsibility/CSR</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Client Onboarding/Getting Started</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Terms of Use</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Subscription/Membership</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Competitions/Contests</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Resource Library</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Company Careers/Career Opportunities</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%">Company History/Timeline</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>                                    
                                </tbody>
                            </table>
                            </div>    
                        </div>                 
                    </div>
                </div>
            </div>
        </section> 
        <div class="gapmob"></div>
        <section class="about_us lightgrey pb-3" data-serialscrolling-target="prices">
            <div class="container">
                <h2 class="main_heading">Quick Overview of Custom Pricing</h2>
                <div class="provider_design mt-2">
                    <table class="table-striped w-100">
                        <tbody><tr>
                            <th style="width:60%;background:#434242;" class="mobwidth">Check List</th>
                            <th style="width:13.3%" class="purple">Basic </th>
                            <th style="width:13.3%" class="green">SME</th>
                            <th style="width:13.3%" class="brown">PRO</th>
                        </tr>
                    </tbody></table>
                    <div id="tableprovider">
                        <div class="collapse show" id="collapseads" style="">
                            <div class="table-responsive">
                                <table class="table-striped w-100">
                                    <tbody>
                                    <tr>
                                        <td style="width:60%" class="mobwidth">Cost of Per Page </td>
                                        <td style="width:13.3%; text-align:center" class="color1">₹599</i></td>
                                        <td style="width:13.3%; text-align:center" class="color2">₹799</td>
                                        <td style="width:13.3%; text-align:center" class="color3">₹999</td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%" class="mobwidth">On Page SEO</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-times" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%" class="mobwidth">.com Domain (Fixed)</td>
                                        <td style="width:13.3%; text-align:center" class="color1">₹399</td>
                                        <td style="width:13.3%; text-align:center" class="color2">₹399</td>
                                        <td style="width:13.3%; text-align:center" class="color3">₹399</td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%" class="mobwidth">Hosting Yearly <small>(From Godaddy/Bigrock)</small></td>
                                        <td style="width:13.3%; text-align:center" class="color1">₹1,499</td>
                                        <td style="width:13.3%; text-align:center" class="color2">₹1,499</td>
                                        <td style="width:13.3%; text-align:center" class="color3">₹1,499</td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%" class="mobwidth">SSL Certificates <small>(From Godaddy/Bigrock)</small></td>
                                        <td style="width:13.3%; text-align:center" class="color1">₹999</td>
                                        <td style="width:13.3%; text-align:center" class="color2">₹999</td>
                                        <td style="width:13.3%; text-align:center" class="color3">₹999</td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%" class="mobwidth">1 Web/Business Mail Id</td>
                                        <td style="width:13.3%; text-align:center" class="color1">₹100</td>
                                        <td style="width:13.3%; text-align:center" class="color2">₹100</td>
                                        <td style="width:13.3%; text-align:center" class="color3">₹100</td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%" class="mobwidth">Payment Gateways  <small>(Paytm, PayPal, 25+ more)</small></td>
                                        <td style="width:13.3%; text-align:center" class="color1">₹3000</td>
                                        <td style="width:13.3%; text-align:center" class="color2">₹3000</td>
                                        <td style="width:13.3%; text-align:center" class="color3">₹3000</td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%" class="mobwidth">Social Media Setup  <small>(FB, Insta, Linkedin, more 5+ platforms)</small></td>
                                        <td style="width:13.3%; text-align:center" class="color1">₹999</td>
                                        <td style="width:13.3%; text-align:center" class="color2">₹999</td>
                                        <td style="width:13.3%; text-align:center" class="color3">₹999</td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%" class="mobwidth">Live Chat Setup</td>
                                        <td style="width:13.3%; text-align:center" class="color1">₹999</td>
                                        <td style="width:13.3%; text-align:center" class="color2">₹999</td>
                                        <td style="width:13.3%; text-align:center" class="color3">₹999</td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%" class="mobwidth">CRM Integration</td>
                                        <td style="width:13.3%; text-align:center" class="color1">₹999</td>
                                        <td style="width:13.3%; text-align:center" class="color2">₹999</td>
                                        <td style="width:13.3%; text-align:center" class="color3">₹999</td>
                                    </tr> 
                                    <tr>
                                        <td style="width:60%" class="mobwidth">Google Map Creation</td>
                                        <td style="width:13.3%; text-align:center" class="color1">₹999</td>
                                        <td style="width:13.3%; text-align:center" class="color2">₹999</td>
                                        <td style="width:13.3%; text-align:center" class="color3">₹999</td>
                                    </tr>
                                    <tr>
                                        <td style="width:60%" class="mobwidth">&nbsp;</td>
                                        <td style="width:13.3%; text-align:center" class="color1"><a class="btn btn-dark" href="javascript:void(0);" id="getquote1">Enquiry</a></td>
                                        <td style="width:13.3%; text-align:center" class="color2"><a class="btn btn-dark" href="javascript:void(0);" id="getquote2">Enquiry</a></td>
                                        <td style="width:13.3%; text-align:center" class="color3"><a class="btn btn-dark" href="javascript:void(0);" id="getquote3">Enquiry</a></td>
                                    </tr>                                   
                                </tbody></table>
                            </div>
                        </div>               
                    </div>
                </div>
            </div>
        </section>  
        <div class="gapmob"></div> 
        <section class="overview">
            <div class="container">
                <h2 class="main_heading">Quick Overview of Website Design</h2>
                <div class="tabspnl">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a class="nav-link active" id="webdesign-tab" data-bs-toggle="tab" data-bs-target="#webdesign" type="button" role="tab" aria-controls="webdesign" aria-selected="true"><i class="fa fa-desktop" aria-hidden="true"></i> Website Designing</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="ecommerce-tab" data-bs-toggle="tab" data-bs-target="#ecommerce" type="button" role="tab" aria-controls="ecommerce" aria-selected="false"><i class="fa fa-shopping-cart" aria-hidden="true"></i> E-Commerce</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="hosting-tab" data-bs-toggle="tab" data-bs-target="#hosting" type="button" role="tab" aria-controls="hosting" aria-selected="false"><i class="fa fa-h-square" aria-hidden="true"></i> Hosting</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="graphic-tab" data-bs-toggle="tab" data-bs-target="#graphic" type="button" role="tab" aria-controls="graphic" aria-selected="false"><i class="fa fa-picture-o" aria-hidden="true"></i> Graphic Design</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="webdesign" role="tabpanel" aria-labelledby="webdesign-tab">
                            <div class="row">
                                <div class="col-sm-6">
                                    <video width="100%" height="220" muted autoplay playsinline loop>
                                        <source src="images/video/webdesign.mp4" type="video/mp4">
                                        <source src="images/video/webdesign.mp4" type="video/ogg">
                                        Your browser does not support the video tag.
                                    </video>
                                </div>
                                <div class="col-sm-6">
                                <h5>Bespoke Solution</h5>
                                <h3>Website Design</h3>
                                <p>With a proven track record, we have successfully delivered website solutions to a wide range of businesses with major clients in India, UK, USA, Australia, Canada, and more countries. We've delivered website solutions for businesses around the world with a client retention rate of 92%, because we sure know how to keep our clients satisfied.</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="ecommerce" role="tabpanel" aria-labelledby="ecommerce-tab">
                            <div class="row">
                                <div class="col-sm-6">
                                    <video width="100%" height="220"  muted autoplay playsinline loop>
                                        <source src="images/video/ecommerce.mp4" type="video/mp4">
                                        <source src="images/video/ecommerce.mp4" type="video/ogg">
                                        Your browser does not support the video tag.
                                    </video>
                                </div>
                                <div class="col-sm-6">
                                <h5>Scalable Solutions</h5>
                                <h3>E-Commerce</h3>
                                <p>With a proven track record, we have successfully delivered website solutions to a wide range of businesses with major clients in India, UK, USA, Australia, Canada, and more countries. We've delivered website solutions for businesses around the world with a client retention rate of 92%, because we sure know how to keep our clients satisfied.</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="hosting" role="tabpanel" aria-labelledby="hosting-tab">
                            <div class="row">
                                <div class="col-sm-6">
                                    <video width="100%" height="220"  muted autoplay playsinline loop>
                                        <source src="images/video/hosting.mp4" type="video/mp4">
                                        <source src="images/video/hosting.mp4" type="video/ogg">
                                        Your browser does not support the video tag.
                                    </video>
                                </div>
                                <div class="col-sm-6">
                                <h5>Managed Solutions</h5>
                                <h3>Hosting Solutions</h3>
                                <p>With a proven track record, we have successfully delivered website solutions to a wide range of businesses with major clients in India, UK, USA, Australia, Canada, and more countries. We've delivered website solutions for businesses around the world with a client retention rate of 92%, because we sure know how to keep our clients satisfied.</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="graphic" role="tabpanel" aria-labelledby="graphic-tab">
                            <div class="row">
                                <div class="col-sm-6">
                                    
                                    <video width="100%" height="220"  muted autoplay playsinlines loop>
                                        <source src="images/video/graphic.mp4" type="video/mp4">
                                        <source src="images/video/graphic.mp4" type="video/ogg">
                                        Your browser does not support the video tag.
                                    </video>
                                </div>
                                <div class="col-sm-6">
                                <h5>Bespoke & Unique</h5>
                                <h3>Graphic Design</h3>
                                <p>With a proven track record, we have successfully delivered website solutions to a wide range of businesses with major clients in India, UK, USA, Australia, Canada, and more countries. We've delivered website solutions for businesses around the world with a client retention rate of 92%, because we sure know how to keep our clients satisfied.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="gapmob"></div>
        <section class="technology lightbrowm pad20"  data-serialscrolling-target="technologies">
            <div class="container">
                <h2 class="main_heading">Technologies and Platforms We Work With</h2>
                <h4 class="tlist">Technologies</h4>
                    <div class="technopanel">
                        <div class="technolist">
                            <div class="technology_list">
                                <h3>Web</h3>
                                <h6>Backend</h6>
                                <ul>
                                    <li><img src="images/technology/dot-net-logo.svg" alt=""></li>
                                    <li><img src="images/technology/go-logo-blue.svg" alt=""></li>
                                    <li><img src="images/technology/java-logo.svg" alt=""></li>
                                    <li><img src="images/technology/node-js.svg" alt=""></li>
                                    <li><img src="images/technology/php-logo.svg" alt=""></li>
                                    <li><img src="images/technology/python.svg" alt=""></li>
                                    <li><img src="images/technology/c-plus-plus.svg" alt=""></li>
                                </ul>
                            </div>
                            <div class="technology_list">
                                <h6>Front End</h6>
                                <ul>
                                    <li><img src="images/technology/html.svg" alt=""></li>
                                    <li><img src="images/technology/css.svg" alt=""></li>
                                    <li><img src="images/technology/javascript-logo.svg" alt=""></li>
                                    <li><img src="images/technology/angular-logo.svg" alt=""></li>
                                    <li><img src="images/technology/react-js-logo.svg" alt=""></li>
                                    <li><img src="images/technology/meteor.svg" alt=""></li>
                                    <li><img src="images/technology/vuejs-logo.svg" alt=""></li>
                                    <li><img src="images/technology/ember-logo.svg" alt=""></li>
                                </ul>
                            </div>
                            <div class="technology_list">
                                <h3>Mobile</h3>
                                <ul>
                                    <li><img src="images/technology/ios-logo.svg" alt=""></li>
                                    <li><img src="images/technology/android-logo.svg" alt=""></li>
                                    <li><img src="images/technology/xamarin-logo-vertical.svg" alt=""></li>
                                    <li><img src="images/technology/cordova-logo.svg" alt=""></li>
                                    <li><img src="images/technology/pwa-logo.svg" alt=""></li>
                                    <li><img src="images/technology/react-native-logo.svg" alt=""></li>
                                    <li><img src="images/technology/flutter-logo.svg" alt=""></li>
                                </ul>
                            </div>
                            <div class="technology_list">
                                <h3>Desktop</h3>
                                <ul>
                                    <li><img src="images/technology/c-plus-plus1.svg" alt=""></li>
                                    <li><img src="images/technology/qt.svg" alt=""></li>
                                    <li><img src="images/technology/c-sharp-logo.svg" alt=""></li>
                                    <li><img src="images/technology/python.svg" alt=""></li>
                                    <li><img src="images/technology/objective-c.svg" alt=""></li>
                                    <li><img src="images/technology/swift.svg" alt=""></li>
                                </ul>
                            </div> 
                            <div class="technology_list">
                                <h3>Platforms</h3>
                                <ul>
                                    <li><img src="images/technology/ms-dynamics-365.svg" alt=""></li>
                                    <li><img src="images/technology/salesforce.svg" alt=""></li>
                                    <li><img src="images/technology/adobe-commerce.svg" alt=""></li>
                                    <li><img src="images/technology/sharepoint-logo-vertical.svg" alt=""></li>
                                    <li><img src="images/technology/servicenow.svg" alt=""></li>
                                    <li><img src="images/technology/power-bi-2020.svg" alt=""></li>
                                    <li><img src="images/technology/sap.svg" alt=""></li>
                                    <li><img src="images/technology/qradar.svg" alt=""></li>
                                </ul>
                            </div> 
                            <div class="technology_list">
                                <h3>Clouds</h3>
                                <ul>
                                    <li><img src="images/technology/aws.svg" alt=""></li>
                                    <li><img src="images/technology/azure-full.svg" alt=""></li>
                                    <li><img src="images/technology/google-cloud-logo.svg" alt=""></li>
                                    <li><img src="images/technology/digital-ocean.svg" alt=""></li>
                                    <li><img src="images/technology/rackspace-horizontal.svg" alt=""></li>
                                </ul>
                            </div> 
                            <div class="technology_list">
                                <h3>Relational databases / data storages</h3>
                                <ul>
                                    <li><img src="images/technology/ms-sql.svg" alt=""></li>
                                    <li><img src="images/technology/mysql.svg" alt=""></li>
                                    <li><img src="images/technology/oracle.svg" alt=""></li>
                                    <li><img src="images/technology/postgresql-vertical-logo.svg" alt=""></li>
                                    <li><img src="images/technology/azure-synapse-analytics-logo.svg" alt=""></li>
                                    <li><img src="images/technology/azure-sql-database-logo.svg" alt=""></li>
                                    <li><img src="images/technology/amazon-rds-logo.svg" alt=""></li>
                                    <li><img src="images/technology/amazon-s3.svg" alt=""></li>
                                    <li><img src="images/technology/google-cloud-sql-1.svg" alt=""></li>
                                </ul>
                            </div>
                            <div class="technology_list">
                                <h3>Big data</h3>
                                <ul>
                                    <li><img src="images/technology/hadoop-logo.svg" alt=""></li>
                                    <li><img src="images/technology/spark.svg" alt=""></li>
                                    <li><img src="images/technology/cassandra.svg" alt=""></li>
                                    <li><img src="images/technology/apache-kafka.svg" alt=""></li>
                                    <li><img src="images/technology/hive.svg" alt=""></li>
                                    <li><img src="images/technology/apache-zookeper-logo.svg" alt=""></li>
                                    <li><img src="images/technology/apache-hbase-logo.svg" alt=""></li>
                                    <li><img src="images/technology/azure-cosmos-db-logo.svg" alt=""></li>
                                    <li><img src="images/technology/azure-blob-storage.svg" alt=""></li>
                                    <li><img src="images/technology/azure-data-lake-logo.svg" alt=""></li>
                                    <li class="techobtn">
                                        <a data-bs-toggle="collapse" href="#bigdata" role="button" aria-expanded="false" aria-controls="bigdata"><i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                    </li>
                                </ul>
                                <div class="collapse" id="bigdata">
                                    <ul>
                                        <li><img src="images/technology/amazon-dynamodb-logo.svg" alt=""></li>
                                        <li><img src="images/technology/amazon-redshift-logo.svg" alt=""></li>
                                        <li><img src="images/technology/amazon-documentdb.svg" alt=""></li>
                                        <li><img src="images/technology/aws-elasticache.svg" alt=""></li>
                                        <li><img src="images/technology/mongodb-logo.svg" alt=""></li>
                                        <li><img src="images/technology/google-cloud-datastore-1.svg" alt=""></li>
                                    </ul>
                                </div>
                            </div>  
                            <div class="technology_list">
                                <h3>Machine learning</h3>
                                <h6>Programming languages & Frameworks</h6>
                                <ul>
                                    <li><img src="images/technology/matlab.jpg" alt=""></li>
                                    <li><img src="images/technology/octave-full.svg" alt=""></li>
                                    <li><img src="images/technology/r_logo.svg" alt=""></li>
                                    <li><img src="images/technology/mahout-logo.svg" alt=""></li>
                                    <li><img src="images/technology/caffe-logo.svg" alt=""></li>
                                    <li><img src="images/technology/mxnet-logo.svg" alt=""></li>
                                    <li><img src="images/technology/tensorflow-logo-vertical.svg" alt=""></li>
                                    <li><img src="images/technology/keras.svg" alt=""></li>
                                    <li><img src="images/technology/torch.svg" alt=""></li>
                                    <li><img src="images/technology/opencv-logo.svg" alt=""></li>
                                    <li><img src="images/technology/theano.svg" alt=""></li>
                                </ul>
                                <h6>Libraries & Cloud services</h6>
                                <ul>
                                    <li><img src="images/technology/spark-mllib-logo.svg" alt=""></li>
                                    <li><img src="images/technology/scikit-learn.svg" alt=""></li>
                                    <li><img src="images/technology/gensim-full.svg" alt=""></li>
                                    <li><img src="images/technology/spacy_logo.svg" alt=""></li>
                                    <li><img src="images/technology/amazon-machine-learning-logo.svg" alt=""></li>
                                    <li><img src="images/technology/amazon-sagemaker.svg" alt=""></li>
                                    <li><img src="images/technology/azure-machine-learning-logo.svg" alt=""></li>
                                    <li><img src="images/technology/google-cloud-ai-platform.svg" alt=""></li>
                                </ul>
                            </div>
                            <div class="technology_list">
                                <h3>DevOps</h3>
                                <h6>Containerization & Automation</h6>
                                <ul>
                                    <li><img src="images/technology/jenkins.svg" alt=""></li>
                                    <li><img src="images/technology/kubernetes-logo.svg" alt=""></li>
                                    <li><img src="images/technology/openshift-logo.svg" alt=""></li>
                                    <li><img src="images/technology/apache-mesos-logo-vertical.svg" alt=""></li>
                                    <li><img src="images/technology/ansible.svg" alt=""></li>
                                    <li><img src="images/technology/puppet.svg" alt=""></li>
                                    <li><img src="images/technology/chef.svg" alt=""></li>
                                    <li><img src="images/technology/saltstack.svg" alt=""></li>
                                    <li><img src="images/technology/terraform-logo.svg" alt=""></li>
                                    <li><img src="images/technology/packer-logo.svg" alt=""></li>
                                </ul>
                                <h6>CI/CD tools</h6>
                                <ul>
                                    <li><img src="images/technology/aws-developer-tools.svg" alt=""></li>
                                    <li><img src="images/technology/azure-devops-logo-vertical.svg" alt=""></li>
                                    <li><img src="images/technology/google-developer-tools.svg" alt=""></li>
                                    <li><img src="images/technology/gitlab-ci-cd-logo.svg" alt=""></li>
                                    <li><img src="images/technology/gitlab.svg" alt=""></li>
                                    <li><img src="images/technology/teamcity.svg" alt=""></li>
                                </ul>
                                <h6>Monitoring</h6>
                                <ul>
                                    <li><img src="images/technology/zabbix-logo.svg" alt=""></li>
                                    <li><img src="images/technology/nagios-logo.svg" alt=""></li>
                                    <li><img src="images/technology/elasticsearch.svg" alt=""></li>
                                    <li><img src="images/technology/prometheus-logo.svg" alt=""></li>
                                    <li><img src="images/technology/grafana-logo.svg" alt=""></li>
                                    <li><img src="images/technology/datadog-logo.svg" alt=""></li>
                                </ul>
                            </div>
                            <div class="technology_list">
                                <h3>Test automation tools</h3>
                                <ul>
                                    <li><img src="images/technology/selenium.svg" alt=""></li>
                                    <li><img src="images/technology/appium.svg" alt=""></li>
                                    <li><img src="images/technology/protractor.svg" alt=""></li>
                                    <li><img src="images/technology/fmbt.svg" alt=""></li>
                                    <li><img src="images/technology/xcuitest.svg" alt=""></li>
                                    <li><img src="images/technology/teststack-white.svg" alt=""></li>
                                    <li><img src="images/technology/xcuit.svg" alt=""></li>
                                    <li><img src="images/technology/ranorex.svg" alt=""></li>
                                    <li class="techobtn">
                                        <a data-bs-toggle="collapse" href="#automation" role="button" aria-expanded="false" aria-controls="automation"><i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                    </li>
                                </ul>
                                <div class="collapse" id="automation">
                                    <ul>
                                        <li><img src="images/technology/postman.svg" alt=""></li>
                                        <li><img src="images/technology/apache-jmeter.svg" alt=""></li>
                                        <li><img src="images/technology/hp-quicktest-professional.svg" alt=""></li>
                                        <li><img src="images/technology/unified-functional-testing.svg" alt=""></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="technology_list">
                                <h3>Information security</h3>
                                <ul>
                                    <li><img src="images/technology/qradar.svg" alt=""></li>
                                    <li><img src="images/technology/cloudflare.svg" alt=""></li>
                                    <li><img src="images/technology/siege-logo.svg" alt=""></li>
                                    <li><img src="images/technology/burpsuite.svg" alt=""></li>
                                    <li><img src="images/technology/nessus.svg" alt=""></li>
                                    <li><img src="images/technology/aircrack-ng.svg" alt=""></li>
                                    <li><img src="images/technology/acunetix.svg" alt=""></li>
                                    <li><img src="images/technology/metasploit-r7.svg" alt=""></li>
                                    <li class="techobtn">
                                        <a data-bs-toggle="collapse" href="#security" role="button" aria-expanded="false" aria-controls="security"><i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                    </li>
                                </ul>
                                <div class="collapse" id="security">
                                    <ul>
                                        <li><img src="images/technology/nmap.svg" alt=""></li>
                                        <li><img src="images/technology/dirb-logo.svg" alt=""></li>
                                        <li><img src="images/technology/wireshark.svg" alt=""></li>
                                        <li><img src="images/technology/zmap.svg" alt=""></li>
                                        <li><img src="images/technology/masscan.svg" alt=""></li>
                                    </ul>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="gapmob"></div>
        <section class="marquee_panel lightgrey">
            <div class="container">
                <div class="marquee-carousel" id="grouploop-1">
                    <div class="item-wrap">
                        <div class="item">
                            <img src="images/brand/elementor.svg" alt="" />
                            <p>Elementor</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/figma.svg" alt="" />
                            <p>Figma</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/godaddy.svg" alt="" />
                            <p>Godaddy</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/mailchimp.svg" alt="" />
                            <p>Mailchimp</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/shopify.svg" alt="" />
                            <p>Shopify</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/sitecore.svg" alt="" />
                            <p>Sitecore</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/squarespace.svg" alt="" />
                            <p>Squarespace</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/webflow.svg" alt="" />
                            <p>Webflow</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/wix.svg" alt="" />
                            <p>Wix</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/wordpress.svg" alt="" />
                            <p>WordPress</p>
                        </div>               
                    </div>
                </div>
                <div class="marquee-carousel" id="grouploop-2">
                    <div class="item-wrap">
                    <div class="item">
                            <img src="images/brand/elementor.svg" alt="" />
                            <p>Elementor</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/sitecore.svg" alt="" />
                            <p>Sitecore</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/squarespace.svg" alt="" />
                            <p>Squarespace</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/webflow.svg" alt="" />
                            <p>Webflow</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/wix.svg" alt="" />
                            <p>Wix</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/wordpress.svg" alt="" />
                            <p>WordPress</p>
                        </div> 
                        <div class="item">
                            <img src="images/brand/godaddy.svg" alt="" />
                            <p>Godaddy</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/mailchimp.svg" alt="" />
                            <p>Mailchimp</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/figma.svg" alt="" />
                            <p>Figma</p>
                        </div>
                        <div class="item">
                            <img src="images/brand/shopify.svg" alt="" />
                            <p>Shopify</p>
                        </div>                                            
                    </div>
                </div>
            </div>
        </section>        
        <div class="gapmob"></div>
        <section class="commonerror lightbrowm"  data-serialscrolling-target="mistakes">
            <div class="container">
                <h2 class="main_heading">Common Errors and Mistakes by SME Website Design - Avoiding the 90% Trap</h2>
                <div class="row pt-2 pb-2">
                    <div class="col-sm-6">
                        <img src="images/seo.webp" alt="" />
                    </div>
                    <div class="col-sm-6">
                        <div class="box_inner">
                            <h2>Avoiding the 90% Trap</h2>
                            <div class="swiper mySwiper">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Assessing Technical Expertise:</b> Clients may overlook the service provider's technical skills, leading to potential issues with the website's functionality and performance.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Overlooking Technical Certifications:</b> Not verifying technical certifications can lead to hiring a company with inadequate qualifications to handle complex projects.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Prioritizing Cost Over Quality:</b> Opting for the cheapest service provider may result in subpar design work and limited technical capabilities.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Reviewing Previous Projects:</b> Neglecting to review the service provider's past projects may lead to hiring a company with a track record of technical errors and inefficiencies.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Checking for Responsive Design:</b> Ignoring the importance of responsive design can result in a website that performs poorly on different devices and screen sizes.</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ignoring SEO and Technical Optimization:</b> A company that doesn't prioritize SEO and technical optimization may result in a website that struggles to rank well in search engines.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Technical Support:</b> Failing to inquire about technical support services can leave clients without assistance when facing website issues.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Discussing Coding Standards:</b> Not discussing coding standards can lead to a messy and hard-to-maintain website codebase.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Neglecting Security Measures:</b> Ignoring security considerations can make the website vulnerable to cyber-attacks and data breaches.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Defining Technical Requirements:</b> Failing to outline technical requirements may lead to misunderstandings and delays in the design process.</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Server Compatibility:</b> Not ensuring that the chosen service provider's design is compatible with the client's hosting server may cause compatibility issues.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ignoring Database Integration:</b> Not discussing database integration can lead to difficulties in managing and organizing website content.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Addressing Cross-Browser Compatibility:</b> Ignoring cross-browser compatibility can result in a website that functions inconsistently across different web browsers.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Load Speed Optimization:</b> Not considering load speed optimization can lead to a slow-loading website, negatively impacting user experience.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ignoring Technical Documentation:</b> A company that doesn't provide proper technical documentation may hinder future website maintenance and updates.</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Scalability in Mind:</b> Failing to consider scalability can make it challenging to expand the website in the future.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Asking About Version Control:</b> Ignoring version control practices can lead to code conflicts and difficulties in managing website changes.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing a Company Without CMS Expertise:</b> Opting for a company without expertise in the preferred Content Management System (CMS) can lead to integration issues.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Neglecting Browser Testing:</b> Not conducting thorough browser testing can result in technical glitches and user experience problems.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ignoring Mobile App Integration:</b> Not discussing mobile app integration can hinder the seamless functioning of mobile applications alongside the website.</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without E-commerce Experience:</b> Opting for a company without e-commerce experience may lead to technical challenges in setting up and managing an online store.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Prioritizing Accessibility Compliance:</b> Ignoring accessibility compliance can exclude users with disabilities from accessing the website.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing a Provider With Limited Technical Services:</b> Opting for a company with limited technical services may require hiring additional vendors for specific technical tasks.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ignoring Technical Training and Handover:</b> Not discussing technical training and handover of the website can result in difficulties for the client in managing the website independently.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Considering Integrations:</b> Failing to consider third-party integrations may lead to technical conflicts and issues with external services.</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without E-commerce Experience:</b> Opting for a company without e-commerce experience may lead to technical challenges in setting up and managing an online store.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Prioritizing Accessibility Compliance:</b> Ignoring accessibility compliance can exclude users with disabilities from accessing the website.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing a Provider With Limited Technical Services:</b> Opting for a company with limited technical services may require hiring additional vendors for specific technical tasks.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ignoring Technical Training and Handover:</b> Not discussing technical training and handover of the website can result in difficulties for the client in managing the website independently.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Considering Integrations:</b> Failing to consider third-party integrations may lead to technical conflicts and issues with external services.</li>
                                        </ul>
                                    </div>  
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Addressing CDN Integration:</b> Neglecting to discuss Content Delivery Network (CDN) integration can impact the website's performance and loading times.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Considering Server Resources:</b> Not assessing server resource requirements may lead to a website that struggles to handle high traffic.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ignoring Technical Testing Procedures:</b> Not discussing technical testing procedures may result in launching a website with unresolved technical issues.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Data Backup and Recovery Plans:</b> Ignoring data backup and recovery plans can lead to data loss in the event of a server crash or security breach.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Inquiring About Website Analytics:</b> Failing to discuss website analytics integration can hinder tracking and analyzing user behavior.</li>
                                        </ul>
                                    </div> 
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Page Speed Optimization Strategies:</b> Not considering page speed optimization strategies can negatively impact user experience and search engine rankings.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ignoring Technical Language Support:</b> Not addressing technical language support can limit the website's accessibility to a global audience.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without User Authentication Consideration:</b> Neglecting to discuss user authentication requirements can lead to security vulnerabilities.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Discussing Technical Performance Monitoring:</b> Failing to discuss technical performance monitoring can make it challenging to identify and address website bottlenecks.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Content Migration Plan:</b> Not having a content migration plan can lead to data loss during the website transition.</li>
                                        </ul>
                                    </div>  
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Discussing Mobile API Integration:</b> Failing to discuss mobile API integration can hinder the smooth functioning of mobile apps connected to the website.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Considering Website Backup Solutions:</b> Not considering website backup solutions can result in data loss during unforeseen incidents.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ignoring Website Maintenance and Update Plans:</b> Not discussing website maintenance and update plans can lead to a stagnant and outdated website.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Technical Performance Optimization:</b> Failing to prioritize technical performance optimization can lead to a sluggish website, affecting user experience.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Addressing Technical Error Logging:</b> Ignoring technical error logging can make it challenging to identify and resolve website issues promptly.</li>  
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Considering Content Versioning:</b> Not discussing content versioning can make it difficult to track content changes over time.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ignoring Technical Support Availability:</b> Not inquiring about technical support availability can lead to delayed responses during critical situations.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Technical SEO Considerations: </b> Not discussing technical SEO considerations can hinder search engine visibility and website traffic.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Prioritizing Website Backup Frequency:</b> Failing to prioritize frequent website backups can result in data loss during unforeseen events.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Website Security Audit:</b> Ignoring website security audits can leave potential vulnerabilities undiscovered.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Not Discussing Website Monitoring Tools:</b> Failing to discuss website monitoring tools can hinder proactive issue detection and resolution.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Choosing Without Considering Future Technical Upgrades:</b> Not considering future technical upgrades can result in outdated technology and limited website capabilities over time.</li> 
                                        </ul>
                                    </div>                                    
                                </div>
                                <div class="swiper-button-next"></div>
                                <div class="swiper-button-prev"></div>
                                <div class="swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="gapmob"></div>
        <section class="commonerror lightgrey" id="featurelist"   data-serialscrolling-target="integration">
            <div class="container">
                <h2 class="main_heading">List of Website Integration Services</h2>
                <p class="text-center">We offer personalized integration services, taking into account industry-specific and competitive factors.</p>
                <div class="row pt-2 pb-2">
                    <div class="col-sm-6">
                        <img src="images/integration.webp" alt="" />
                    </div>
                    <div class="col-sm-6">
                        <div class="box_inner">
                            <div class="swiper mySwiper">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <h2>Basic Integration Features:</h2>
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i>WhatsApp Account Integration</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Social Media Accounts Integration</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Google Map Integration</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Social Sharing Buttons</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Customer Review Platforms (Google Reviews, etc.)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with E-commerce Platforms (Shopify, WooCommerce)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Payment Gateways (PayPal, Stripe)</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                    <h2>Premium Integration Features:</h2>
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Google Business Listing Integration </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Google Analytics Account Integration </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Customized Live Chat Integration </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Location-Based Services (Google Maps, Store Locator) </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Booking or Appointment Scheduling System </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with CRM (Customer Relationship Management) System </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Customer Support Ticketing System </li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                    <h2>Basic Integration Features:</h2>
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Content Management Systems (WordPress, Drupal)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Language Translation Services</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Affiliate Marketing Platforms</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with User-generated Content Aggregators</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Data Visualization Tools</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with SMS Notification Services</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Stock Image Libraries</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <h2>Premium Integration Features:</h2>
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Social Media Feeds (Instagram, Facebook, etc.)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Analytics Tools to Track Website Performance</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Live Chat or Customer Support Platforms</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Video Hosting Platforms (YouTube, Vimeo)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with E-commerce Shipping and Tracking Services</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Event Management Platforms</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Job Application and Recruitment Systems</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <h2>Basic Integration Features:</h2>
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Online Survey and Polling Platforms </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Community and Forum Platforms </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Donation and Fundraising Platforms </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Interactive Maps and Wayfinding </li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                     <h2>Premium Integration Features:</h2>
                                        <ul>  
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Webinar Hosting Platforms</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Event Registration and Ticketing Systems</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Social Proof Notifications (Recent Sales, Sign-ups)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Weather Updates</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with CRM and Marketing Automation Tools</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Chatbots and AI Assistants</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Podcast Hosting and Distribution</li>
                                        </ul>
                                    </div>  
                                    <div class="swiper-slide">
                                    <h2>Premium Integration Features:</h2>
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Voice Assistants (Amazon Alexa, Google Assistant)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Appointment Reminders (SMS, Email)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Social Media Advertising Platforms</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Recruitment and HR Management Systems</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Knowledge Base and Help Center Systems</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with API for Custom Functionality</li>
                                        </ul>
                                    </div>                                    
                                </div>
                                <div class="swiper-button-next"></div>
                                <div class="swiper-button-prev"></div>
                                <div class="swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="gapmob"></div>
        <section class="commonerror lightbrowm">
            <div class="container">
                <h2 class="main_heading">Important Information to Know Before Selecting Website Design Company</h2>
                <div class="row pt-2 pb-2">
                    <div class="col-sm-6">
                        <img src="images/integration.webp" alt="" />
                    </div>
                    <div class="col-sm-6">
                        <div class="box_inner">
                            <div class="swiper mySwiper">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Portfolio and Experience:</b> Review the company's portfolio to assess the quality and diversity of their previous work. Look for experience in designing websites similar to your industry or business niche.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Client Testimonials and Reviews:</b> Read client testimonials and reviews to gauge the company's reputation, reliability, and customer satisfaction. Look for feedback on their communication, responsiveness, and project delivery.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Team Skills and Qualifications:</b> Evaluate the skills and qualifications of the company's team members. Check if they have expertise in various web technologies, coding languages, and design tools.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ongoing Support and Maintenance:</b>Inquire about post-launch support, maintenance services, and website updates. Determine the company's availability and response time for resolving issues or implementing changes.</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Pricing and Budget:</b> Request a detailed breakdown of the pricing structure and understand what services are included. Compare the cost with the value and services provided to ensure it aligns with your budget and expectations.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Intellectual Property Rights:</b> Clarify ownership of the website design, graphics, and content. Ensure you have the rights to use and modify the design elements in the future.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Security Measures:</b> Inquire about the company's security practices to protect your website from potential vulnerabilities, data breaches, or cyber attacks. Ask about SSL certificates, backup procedures, and security protocols.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Contract Terms and Agreements:</b> Review the contract terms, payment schedule, cancellation policy, and intellectual property rights to ensure they are fair, transparent, and protect your interests.</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Speed and Performance Optimization:</b> Discuss the company's strategies for optimizing website speed and performance, including techniques like caching, file compression, code minification, and server-side optimizations.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ethical and Sustainable Design:</b> Discuss the company's commitment to ethical design practices, such as data privacy, transparent data usage, and sustainable web hosting options to minimize the environmental impact of the website.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Case Studies and Success Stories:</b> Request case studies and success stories that highlight the company's expertise, showcasing how their website designs have positively impacted businesses and achieved measurable results.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Client Education and Training:</b> A good website designing company will not only deliver a functional website but also provide training and education on how to manage and update the website independently, empowering you to make changes and add new content.</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Confidentiality and Non-Disclosure:</b> If your website contains sensitive information or proprietary data, ensure that the company adheres to strict confidentiality agreements and non-disclosure policies to protect your intellectual property.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Analytics and Tracking:</b> Check if the company helps you set up website analytics and tracking tools to monitor user behavior, track conversions, and gather insights to make data-driven decisions for further optimization.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Cross-Browser Compatibility:</b> Ensure that the company tests and optimizes websites for compatibility across various web browsers and devices, ensuring consistent user experiences and functionality.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Website Maintenance and Support:</b> Discuss the company's website maintenance and support services, including security updates, bug fixes, content updates, and ongoing technical support to ensure the website's long-term success.</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Website Development Process:</b> Inquire about the company's website development process, from initial planning to design, development, and launch. Understand how they involve clients in the process and accommodate revisions or changes.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Integration with Third-Party Tools:</b> Determine if the company can integrate third-party tools or services you require, such as payment gateways, CRM systems, or marketing automation platforms.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Emerging Technologies Integration:</b> Check if the company stays updated with emerging web technologies and trends, such as voice search, chatbots, virtual reality, or augmented reality, and their capability to integrate these technologies into website designs.</li>
                                        </ul>
                                    </div>                                    
                                </div>
                                <div class="swiper-button-next"></div>
                                <div class="swiper-button-prev"></div>
                                <div class="swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>       
        <div class="gapmob"></div>        
    </main> 
    <footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 footerfirst">
                <h3>Connect with Our Team</h3>
                <h5>General Inquiries</h5>
                <ul>
                    <li><a href="tel:9999123123"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 9999-123-123</a></li>
                    <li><a href="mailto:info@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: info@ppc5g.com</a></li>
                </ul>
                <h5>PPC Support Team</h5>
                <ul>
                    <li><a href="tel:8588001122"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 8588-001122</a></li>
                    <li><a href="mailto:support@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: support@ppc5g.com</a></li>
                </ul>
                <h5>PPC Audit & Consultancy</h5>
                <ul>
                    <li><a href="tel:7777909090"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 7777-909090</a></li>
                    <li><a href="mailto:audit@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: audit@ppc5g.com</a></li>
                </ul>
            </div>
            <div class="col-sm-4 footerfirst">
                <h3>Contact with Us</h3>
                <ul>
                <li><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 626, 6th Floor, Signature Global Mall,<br>Sector-3, Vaishali, Ghaziabad,<br> Uttar Pradesh-201010</a></li>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.4736342932583!2d77.3329667742235!3d28.645533783492468!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x64662107506a59b3%3A0x1952eb50974829ec!2sWeb5G%20Technology%20Private%20Limited!5e0!3m2!1sen!2sin!4v1695913605459!5m2!1sen!2sin" width="100%" height="220" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </ul>
            </div>
        </div>
    </div>
    <div class="copyright">
        <p>© 2023 PPC5G Technology Pvt. Ltd. All Right Reserved.</p>
    </div>
</footer>      
    <div class="modal-overlay" id="modalContainer">
        <div class="modal-content" id="modal">
            <span class="close-btn" id="closeModalBtn">&times;</span>
            <h2 id="modalTitle"></h2>
            <p id="modalContent" class="scroll-container " style="text-align: justify;"></p>
        </div>
    </div>
    <div id="backgroundOverlay"></div>
    <div id="overlay"></div>
<div class="modal modal-bottom fade modelredesign" id="bottom_modal" tabindex="-1" role="dialog" aria-labelledby="bottom_modal">
        <div class="modal-dialog modelani" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times; Close</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="inner_model">
                    <h5 class="modal-title">Important Discussion with Our PPC Expert Before Starting </h5>
                    <h6>Google Ads</h6>
                    <p><b>Understanding Your Business Objectives and Goals:</b> We'll start by understanding your business's primary objectives and specific goals for running Google Ads. This helps us tailor our strategies to align perfectly with your aspirations.</p>
                    <p><b>Identifying Your Target Audience and Buyer Personas:</b> Understanding who your target audience is and creating detailed buyer personas are essential steps in creating effective advertising campaigns. We will collaborate with you to identify your ideal customers and gather important information about them. This will help us design advertisements that truly connect with your potential customers and speak to their specific needs and preferences.</p>
                    <p><b>Evaluating Your Website Readiness:</b> We'll check your website's suitability for ads, suggest conversion-friendly improvements, and ensure a seamless user experience to boost desired actions and campaign success.</p>
                    <p><b>Determining Your Budget Allocation:</b> Budget management is a key aspect of running successful Google Ads campaigns. We'll discuss your budget and allocate it strategically across different campaigns and ad groups to maximize results.</p>
                    <p><b>Addressing Advertising Risks:</b> Every advertising campaign carries potential risks. Our focus is on identifying challenges like low conversions, dangerous competition, and unpredictable outcomes. We'll propose effective strategies to minimize these risks.</p>
                    <p><b>Exploring Advertising History Across Platforms, Locations, and Conversions:</b> We'll review your past advertising experiences, looking into various platforms, geographical locations, and past conversion data. This historical analysis will provide valuable insights to guide our strategies for future success.</p>
                    <p><b>Determining If Google Ads Fits Your Business:</b> Let's analyze if Google Ads is the right fit for your business based on your profit margins with products or services. Although Many people use Google Ads, we need to check if it suits your goals and objectives.</p>
                    <p><b>Assessing Risks of Running Ads and Budget Spending:</b> Before we begin, let's talk about the potential risks involved in running Google Ads and investing your budget. It's important to be aware of challenges like low conversions, market competition, and unpredictable outcomes.</p>
                    <p><b>Customer Lifetime Value (LTV) and Real Value of Conversions:</b>We will explore the long-term value of your customers (LTV) and its connection to the actual value of conversions from advertising. This understanding guides us in making informed decisions and optimizing your budget wisely.</p>
                    <p><b>Learning from Past Marketing Efforts:</b> If you've engaged in marketing before, we'll review your past experiences to learn from what worked and what didn't. This way, we can fine-tune our approach and build on successful aspects.</p>
                    <p><b>Addressing Your Concerns and Questions:</b> We value open communication, so we'll provide ample time for you to ask any questions or express any concerns you may have about Google Ads and its management.</p>
                 </div>
            </div>
            <div class="modal-footer modal-footer-fixed d-none">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
            </div>
        </div>
    </div>   
    <div class="websiteactive">
        <div class="menu_overlay">
    <div id="menuopen" class="menuslide">
        <img src="images/ppclogo.png" alt="" />
        <span class="comtitle">Web5G Technology Pvt. Ltd</span>
        <button id="menuclose"><i class="fa fa-times" aria-hidden="true"></i>   </button>
        <div class="menu_body">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="ppc-services.php">Google Ads Services</a></li>
                <li><a href="landing-page.php">Landing Page Design Services</a></li>
                <li><a href="website-design.php">Website Design Services</a></li>
                <li><a href="javascript:void(0);" class="slidedownmenu">About Us<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                    <ul class="slidemenu">
                        <li><a href="about-us.php">About Us</a></li>
                        <li><a href="about-director.php">About Director</a></li>
                    </ul>
                </li>
                <li><a href="legal.php">Legal</a></li>
                <li><a href="privacy-policy.php">Privacy Policy</a></li>
            </ul>
        </div>
    </div>
</div>    </div>
    <div class="review_overlay">
    <div id="reviewone" class="review">
        <button id="closeone" class="close"><i class="fa fa-times-circle" aria-hidden="true"></i> Close</button>
        <div class="inner_model webreviewlist">
            <h3>Exclusive Reasons Why Clients Love Us</h3>
            <p><span class="reviewline">&#8213;</span> Our clients appreciate our ability to craft custom designs that perfectly align with their brand identity and vision.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> They admire our skill in creating websites with user-friendly layouts, ensuring a seamless experience for their visitors.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> Clients value our dedication to ensuring their websites function flawlessly on various devices, including smartphones and tablets.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> Our technical expertise in handling complex website projects impresses and instills confidence in our clients.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> Our proven track record of successful website designs fosters trust and reinforces their belief in our capabilities.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> Clients love the fact that we prioritize website speed, resulting in longer visitor engagement and improved user experiences.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> They commend our strategic use of technical SEO strategies, which positively impact their website's search engine rankings.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> The strong security measures we employ to protect their website and data contribute significantly to their peace of mind.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> Our prompt and effective communication keeps them informed about the progress of their website projects.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> They appreciate our provision of user-friendly content management systems, enabling easy updates to their website content.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> Clients commend our transparent and fair pricing structure, providing clarity and ensuring no surprises in project costs.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> Our adherence to industry standards and best practices assures them of reliable and trustworthy websites.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> They value our continuous support after the website launch, addressing any issues promptly to ensure smooth operations.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> Clients appreciate our commitment to web accessibility, creating inclusive websites that cater to all users, including those with disabilities.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> They recognize our designs' scalability and adaptability, allowing their websites to grow and evolve with their business needs.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> The intuitive navigation we implement on their websites ensures visitors can easily find the information they seek.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> They are pleased with our focus on cross-browser compatibility, guaranteeing consistent performance across various web browsers.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> Clients commend us for delivering projects on time, respecting deadlines, and ensuring timely website launches.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> They appreciate our expertise in improving website performance, helping them achieve their business objectives.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> Clients value our robust data backup and recovery plans, assuring the safety and continuity of their website.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> They find value in our ability to make their websites multilingual, facilitating global reach and audience engagement.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> We provide comprehensive documentation, empowering clients to manage their websites with confidence.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> Clients enjoy the flexibility of customized features, tailoring their websites to suit specific requirements.</p>
        </div>
    </div>
</div>
<div class="review_overlay">
    <div id="reviewtwo" class="review">
        <button id="closetwo" class="close"><i class="fa fa-times-circle" aria-hidden="true"></i> Close</button>
        <div class="inner_model webreviewlist">
            <h3>Additional professional services that provide extra value</h3>
            <p><span class="reviewline">&#8213;</span> <b>Web Performance Optimization:</b> Optimizing website speed, page load times, and overall performance to enhance user experience and reduce bounce rates.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> <b>User Behavior Analysis:</b> Utilizing advanced analytics tools to analyze user behavior on websites, gaining insights into user interactions, preferences, and pain points to inform website design and optimization strategies.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> <b>Website Security:</b> Implementing robust security measures, SSL certificates, and regular updates to protect websites from security threats and ensure data privacy. </p>
            <hr>
            <p><span class="reviewline">&#8213;</span> <b>Website Maintenance and Support:</b> Providing ongoing technical support, regular updates, and maintenance services to ensure website stability, security, and optimal performance.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> <b>Website Analytics and Tracking:</b> Setting up analytics tools, heatmaps, and conversion tracking to measure and analyze website performance, user behavior, and key metrics.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> <b>Mobile Optimization:</b> Ensuring that the website is optimized for mobile devices, including responsive design, mobile-friendly elements, and fast loading times for an optimal mobile user experience.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> <b>Microinteractions and Animated Elements:</b>  Incorporating subtle and interactive animations, microinteractions, and engaging transitions to create delightful user experiences and capture users' attention.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> <b>Website Security Audits:</b> Conducting comprehensive security audits to identify vulnerabilities, implementing necessary security measures, and providing ongoing monitoring and protection against cyber threats.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> <b>Website Speed Audit:</b> Conducting a thorough audit of the website's speed performance to identify areas of improvement and potential bottlenecks.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> <b>Image Optimization:</b> Optimizing images by compressing file sizes, resizing dimensions, and implementing lazy loading techniques to reduce load times without compromising image quality.</p>
            <hr>
            <p><span class="reviewline">&#8213;</span> <b>Enabling and Seamlessly Integrating Cache Techniques:</b> Enabling and seamlessly integrating cache techniques like browser caching, server-side caching, and content delivery network (CDN) caching to proficiently store static elements and amplify their distribution effectiveness.</p>
            <hr>
            
        </div>
    </div>
</div>
<div class="review_overlay">
    <div id="reviewthree" class="review">
        <button id="closethree" class="close"><i class="fa fa-times-circle" aria-hidden="true"></i> Close</button>
        <h3>Get A Quote Now</h3>
        <div class="inner_model">
            <div class="details_form mt-3 mb-3">
                <form action="https://website5g.com/mailppc.php" method="post" id="form2">
                    <select name="package" class="form-control" readonly>
                        <option value="Basic">BASIC</option>
                    </select>
                    <label>Enter Your Name <span style="color:red;">*</span></label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/user.png" alt="" /></span>
                        </div>
                        <input type="text" class="form-control" placeholder="Enter Your Name" name="name" aria-label="Name" required>
                    </div>
                    <label>Enter Your Email <span style="color:red;">*</span></label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/email.png" alt="" /></span>
                        </div>
                        <input type="email" name="email"  class="form-control" placeholder="Enter Your Email" aria-label="Name"  required>
                    </div>
                    <label>Enter Your Number <span style="color:red;">*</span></label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/india-flag.png" alt="" /> &nbsp; +91</span>
                        </div>
                        <input class="inputs two form-control" type="tel" maxlength="1" placeholder="x"  name="tel1" size="1" required >
                        <input class="inputs two form-control" type="tel" maxlength="1" placeholder="x"  name="tel2"  size="1" required >
                        <input class="inputs two form-control" type="tel" maxlength="1" placeholder="x"  name="tel3"  size="1" required >
                        <input class="inputs two form-control" type="tel" maxlength="1" placeholder="x"  name="tel4"  size="1" required >
                        <input class="inputs two form-control mr1" type="tel" maxlength="1" placeholder="x"  name="tel5"  size="1" required >
                        <input class="inputs two form-control ml1" type="tel" maxlength="1" placeholder="x"  name="tel6"  size="1" required >
                        <input class="inputs two form-control" type="tel" maxlength="1" placeholder="x"  name="tel7"  size="1" required >
                        <input class="inputs two form-control" type="tel" maxlength="1" placeholder="x"  name="tel8"  size="1" required >
                        <input class="inputs two form-control" type="tel" maxlength="1" placeholder="x"  name="tel9"  size="1" required >
                        <input class="inputs two form-control" type="tel" maxlength="1" placeholder="x"  name="tel10"  size="1" required >
                    </div>
                    <label>Enter Your City <span style="color:red;">*</span></label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/map.png" alt="" /></span>
                        </div>
                        <input type="text" name="city" class="form-control" placeholder="Enter Your City" aria-label="Name" required>
                    </div>
                    <label>Enquiry About (Optional)</label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/enquiry.png" alt=""></span>
                        </div>
                        <input type="text" name="message" class="form-control" placeholder="Enter your Enquiry">
                    </div>
                     <div class="pagesnumber">
                        <label>Want to Select Number of Pages</label>
                       <input type="radio" name="numberpages" value="no"> No
                       <input type="radio" name="numberpages" value="yes"> Yes
                    </div>
                    <div class="pagesselect hide">
                       <label><input type="radio" name="pagesnumber" value="1 to 5"> 1 to 5</label>
                       <label><input type="radio" name="pagesnumber" value="5 to 10"> 5 to 10</label>
                       <label><input type="radio" name="pagesnumber" value="5 to 10"> 10 to 25</label>
                       <label><input type="radio" name="pagesnumber" value="25+"> 25+</label>
                       <label><input type="radio" name="pagesnumber" value="Other"> Other</label>
                    </div>

                    <div class="requirements">
                        <label>Want to Select Other Requirements</label>
                       <input type="radio" name="requirementsradio" value="no"> No
                       <input type="radio" name="requirementsradio" value="yes"> Yes
                    </div>
                    <div class="requiment hide">
                        <label><input type="checkbox" name="req1" value=".com Domain">.com Domain</label>
                        <label><input type="checkbox" name="req2" value="Hosting ">Hosting </label>
                        <label><input type="checkbox" name="req3" value="SSL Certificates">SSL Certificates</label>
                        <label><input type="checkbox" name="req4" value="Web/Business Mail Id ">Web/Business Mail Id </label>
                        <label><input type="checkbox" name="req5" value="Other">Other </label>
                    </div>
                    <div class="checklist">
                        <label>Want to See Other Checklist </label>
                       <input type="radio" name="checklistradio" value="no"> No
                       <input type="radio" name="checklistradio" value="yes"> Yes
                    </div>
                    <div class="checklistshow hide">
                        <label><input type="checkbox" name="req6" value="On Page SEO">On Page SEO</label>
                        <label><input type="checkbox" name="req7" value="Live Chat Integration ">Live Chat Integration </label>
                        <label><input type="checkbox" name="req8" value="Social Media Creation">Social Media Creation (FB, Insta, Linkedin, more 5+ platforms) </label>
                        <label><input type="checkbox" name="req9" value="Payment Gateways ">Payment Gateways (Paytm, PayPal, 7+ more)</label>
                        <label><input type="checkbox" name="req10" value="Google Map/Listing">Google Map/Listing</label>
                        <label><input type="checkbox" name="req11" value="Google Analytics">Google Analytics</label>
                        <label><input type="checkbox" name="req12" value="CRM Integration">CRM Integration</label>
                        <label><input type="checkbox" name="req13" value="Database Integration">Database Integration</label>
                        <label><input type="checkbox" name="req14" value="Other">Other</label>
                    </div>
                    <input type="submit" name="submit" class="form-control mb-2 btn btn-primary" value="Submit &amp; Get A Call Back ">
                </form>
            </div>
        </div>
    </div>
</div>
<div class="review_overlay">
    <div id="reviewfour" class="review">
        <button id="closefour" class="close"><i class="fa fa-times-circle" aria-hidden="true"></i> Close</button>
        <h3>Get A Quote Now</h3>
        <div class="inner_model">
            <div class="details_form mt-3 mb-3">
                <form action="https://website5g.com/mailppc.php" method="post" id="form3">
                    <select name="package" class="form-control" readonly>
                        <option value="SME">SME</option>
                    </select>
                    <label>Enter Your Name <span style="color:red;">*</span></label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/user.png" alt="" /></span>
                        </div>
                        <input type="text" class="form-control" placeholder="Enter Your Name" name="name" aria-label="Name" required>
                    </div>
                    <label>Enter Your Email <span style="color:red;">*</span></label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/email.png" alt="" /></span>
                        </div>
                        <input type="email" name="email"  class="form-control" placeholder="Enter Your Email" aria-label="Name"  required>
                    </div>
                    <label>Enter Your Number <span style="color:red;">*</span></label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/india-flag.png" alt="" /> &nbsp; +91</span>
                        </div>
                        <input class="inputs three form-control" type="tel" maxlength="1" placeholder="x"  name="tel1" size="1" required >
                        <input class="inputs three form-control" type="tel" maxlength="1" placeholder="x"  name="tel2"  size="1" required >
                        <input class="inputs three form-control" type="tel" maxlength="1" placeholder="x"  name="tel3"  size="1" required >
                        <input class="inputs three form-control" type="tel" maxlength="1" placeholder="x"  name="tel4"  size="1" required >
                        <input class="inputs three form-control mr1" type="tel" maxlength="1" placeholder="x"  name="tel5"  size="1" required >
                        <input class="inputs three form-control ml1" type="tel" maxlength="1" placeholder="x"  name="tel6"  size="1" required >
                        <input class="inputs three form-control" type="tel" maxlength="1" placeholder="x"  name="tel7"  size="1" required >
                        <input class="inputs three form-control" type="tel" maxlength="1" placeholder="x"  name="tel8"  size="1" required >
                        <input class="inputs three form-control" type="tel" maxlength="1" placeholder="x"  name="tel9"  size="1" required >
                        <input class="inputs three form-control" type="tel" maxlength="1" placeholder="x"  name="tel10"  size="1" required >
                    </div>
                    <label>Enter Your City <span style="color:red;">*</span></label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/map.png" alt="" /></span>
                        </div>
                        <input type="text" name="city" class="form-control" placeholder="Enter Your City" aria-label="Name" required>
                    </div>
                    <label>Enquiry About (Optional)</label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/enquiry.png" alt=""></span>
                        </div>
                        <input type="text" name="message" class="form-control" placeholder="Enter your Enquiry">
                    </div>
                     <div class="pagesnumber">
                        <label>Want to Select Number of Pages</label>
                       <input type="radio" name="numberpages" value="no"> No
                       <input type="radio" name="numberpages" value="yes"> Yes
                    </div>
                    <div class="pagesselect hide">
                       <label><input type="radio" name="pagesnumber" value="1 to 5"> 1 to 5</label>
                       <label><input type="radio" name="pagesnumber" value="5 to 10"> 5 to 10</label>
                       <label><input type="radio" name="pagesnumber" value="5 to 10"> 10 to 25</label>
                       <label><input type="radio" name="pagesnumber" value="25+"> 25+</label>
                       <label><input type="radio" name="pagesnumber" value="Other"> Other</label>
                    </div>

                    <div class="requirements">
                        <label>Want to Select Other Requirements</label>
                       <input type="radio" name="requirementsradio" value="no"> No
                       <input type="radio" name="requirementsradio" value="yes"> Yes
                    </div>
                    <div class="requiment hide">
                        <label><input type="checkbox" name="req1" value=".com Domain">.com Domain</label>
                        <label><input type="checkbox" name="req2" value="Hosting ">Hosting </label>
                        <label><input type="checkbox" name="req3" value="SSL Certificates">SSL Certificates</label>
                        <label><input type="checkbox" name="req4" value="Web/Business Mail Id ">Web/Business Mail Id </label>
                        <label><input type="checkbox" name="req5" value="Other">Other </label>
                    </div>
                    <div class="checklist">
                        <label>Want to See Other Checklist </label>
                       <input type="radio" name="checklistradio" value="no"> No
                       <input type="radio" name="checklistradio" value="yes"> Yes
                    </div>
                    <div class="checklistshow hide">
                        <label><input type="checkbox" name="req6" value="On Page SEO">On Page SEO</label>
                        <label><input type="checkbox" name="req7" value="Live Chat Integration ">Live Chat Integration </label>
                        <label><input type="checkbox" name="req8" value="Social Media Creation">Social Media Creation (FB, Insta, Linkedin, more 5+ platforms) </label>
                        <label><input type="checkbox" name="req9" value="Payment Gateways ">Payment Gateways (Paytm, PayPal, 7+ more)</label>
                        <label><input type="checkbox" name="req10" value="Google Map/Listing">Google Map/Listing</label>
                        <label><input type="checkbox" name="req11" value="Google Analytics">Google Analytics</label>
                        <label><input type="checkbox" name="req12" value="CRM Integration">CRM Integration</label>
                        <label><input type="checkbox" name="req13" value="Database Integration">Database Integration</label>
                        <label><input type="checkbox" name="req14" value="Other">Other</label>
                    </div>
                    <input type="submit" name="submit" class="form-control mb-2 btn btn-primary" value="Submit &amp; Get A Call Back ">
                </form>
            </div>
        </div>
    </div>
</div>
<div class="review_overlay">
    <div id="reviewfive" class="review">
        <button id="closefive" class="close"><i class="fa fa-times-circle" aria-hidden="true"></i> Close</button>
        <h3>Get A Quote Now</h3>
        <div class="inner_model">
            <div class="details_form mt-3 mb-3">
                <form action="https://website5g.com/mailppc.php" method="post" id="form4">
                    <select name="package" class="form-control" readonly>
                        <option value="PRO">PRO</option>
                    </select>
                    <label>Enter Your Name <span style="color:red;">*</span></label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/user.png" alt="" /></span>
                        </div>
                        <input type="text" class="form-control" placeholder="Enter Your Name" name="name" aria-label="Name" required>
                    </div>
                    <label>Enter Your Email <span style="color:red;">*</span></label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/email.png" alt="" /></span>
                        </div>
                        <input type="email" name="email"  class="form-control" placeholder="Enter Your Email" aria-label="Name"  required>
                    </div>
                    <label>Enter Your Number <span style="color:red;">*</span></label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/india-flag.png" alt="" /> &nbsp; +91</span>
                        </div>
                        <input class="inputs four form-control" type="tel" maxlength="1" placeholder="x"  name="tel1" size="1" required >
                        <input class="inputs four form-control" type="tel" maxlength="1" placeholder="x"  name="tel2"  size="1" required >
                        <input class="inputs four form-control" type="tel" maxlength="1" placeholder="x"  name="tel3"  size="1" required >
                        <input class="inputs four form-control" type="tel" maxlength="1" placeholder="x"  name="tel4"  size="1" required >
                        <input class="inputs four form-control mr1" type="tel" maxlength="1" placeholder="x"  name="tel5"  size="1" required >
                        <input class="inputs four form-control ml1" type="tel" maxlength="1" placeholder="x"  name="tel6"  size="1" required >
                        <input class="inputs four form-control" type="tel" maxlength="1" placeholder="x"  name="tel7"  size="1" required >
                        <input class="inputs four form-control" type="tel" maxlength="1" placeholder="x"  name="tel8"  size="1" required >
                        <input class="inputs four form-control" type="tel" maxlength="1" placeholder="x"  name="tel9"  size="1" required >
                        <input class="inputs four form-control" type="tel" maxlength="1" placeholder="x"  name="tel10"  size="1" required >
                    </div>
                    <label>Enter Your City <span style="color:red;">*</span></label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/map.png" alt="" /></span>
                        </div>
                        <input type="text" name="city" class="form-control" placeholder="Enter Your City" aria-label="Name" required>
                    </div>
                    <label>Enquiry About (Optional)</label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/enquiry.png" alt=""></span>
                        </div>
                        <input type="text" name="message" class="form-control" placeholder="Enter your Enquiry">
                    </div>
                     <div class="pagesnumber">
                        <label>Want to Select Number of Pages</label>
                       <input type="radio" name="numberpages" value="no"> No
                       <input type="radio" name="numberpages" value="yes"> Yes
                    </div>
                    <div class="pagesselect hide">
                       <label><input type="radio" name="pagesnumber" value="1 to 5"> 1 to 5</label>
                       <label><input type="radio" name="pagesnumber" value="5 to 10"> 5 to 10</label>
                       <label><input type="radio" name="pagesnumber" value="5 to 10"> 10 to 25</label>
                       <label><input type="radio" name="pagesnumber" value="25+"> 25+</label>
                       <label><input type="radio" name="pagesnumber" value="Other"> Other</label>
                    </div>

                    <div class="requirements">
                        <label>Want to Select Other Requirements</label>
                       <input type="radio" name="requirementsradio" value="no"> No
                       <input type="radio" name="requirementsradio" value="yes"> Yes
                    </div>
                    <div class="requiment hide">
                        <label><input type="checkbox" name="req1" value=".com Domain">.com Domain</label>
                        <label><input type="checkbox" name="req2" value="Hosting ">Hosting </label>
                        <label><input type="checkbox" name="req3" value="SSL Certificates">SSL Certificates</label>
                        <label><input type="checkbox" name="req4" value="Web/Business Mail Id ">Web/Business Mail Id </label>
                        <label><input type="checkbox" name="req5" value="Other">Other </label>
                    </div>
                    <div class="checklist">
                        <label>Want to See Other Checklist </label>
                       <input type="radio" name="checklistradio" value="no"> No
                       <input type="radio" name="checklistradio" value="yes"> Yes
                    </div>
                    <div class="checklistshow hide">
                        <label><input type="checkbox" name="req6" value="On Page SEO">On Page SEO</label>
                        <label><input type="checkbox" name="req7" value="Live Chat Integration ">Live Chat Integration </label>
                        <label><input type="checkbox" name="req8" value="Social Media Creation">Social Media Creation (FB, Insta, Linkedin, more 5+ platforms) </label>
                        <label><input type="checkbox" name="req9" value="Payment Gateways ">Payment Gateways (Paytm, PayPal, 7+ more)</label>
                        <label><input type="checkbox" name="req10" value="Google Map/Listing">Google Map/Listing</label>
                        <label><input type="checkbox" name="req11" value="Google Analytics">Google Analytics</label>
                        <label><input type="checkbox" name="req12" value="CRM Integration">CRM Integration</label>
                        <label><input type="checkbox" name="req13" value="Database Integration">Database Integration</label>
                        <label><input type="checkbox" name="req14" value="Other">Other</label>
                    </div>
                    <input type="submit" name="submit" class="form-control mb-2 btn btn-primary" value="Submit &amp; Get A Call Back ">
                </form>
            </div>
        </div>
    </div>
</div>
<div class="review_overlay">
    <div id="reviewsix" class="review">
        <button id="closesix" class="close"><i class="fa fa-times-circle" aria-hidden="true"></i> Close</button>
            </div>
</div>
<div class="review_overlay">
    <div id="revieweight" class="review">
        <button id="closeeight" class="close"><i class="fa fa-times-circle" aria-hidden="true"></i> Close</button>
            </div>
</div>
<div class="review_overlay">
    <div id="reviewseven" class="review">
        <button id="closeseven" class="close"><i class="fa fa-times-circle" aria-hidden="true"></i> Close</button>
            <div class="details_form ">
                <h2>Get A Quote Now</h2>
                <form action="mail.php" method="post" id="form7">
                    <label>Enter Your Name</label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/user.png" alt="" /></span>
                        </div>
                        <input type="text" class="form-control" placeholder="Enter Your Name" name="name" required>
                    </div>
                    <label>Enter Your Email</label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text" ><img src="images/email.png" alt="" /></span>
                        </div>
                        <input type="email" name="email"  class="form-control" placeholder="Enter Your Email" required>
                    </div>
                    <label>Enter Your Number</label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text" ><img src="images/india-flag.png" alt="" /> &nbsp; +91</span>
                        </div>
                        <input class="inputs seven form-control" type="tel" maxlength="1" placeholder="x"  name="tel1" size="1" required >
                        <input class="inputs seven form-control" type="tel" maxlength="1" placeholder="x"  name="tel2"  size="1" required >
                        <input class="inputs seven form-control" type="tel" maxlength="1" placeholder="x"  name="tel3"  size="1" required >
                        <input class="inputs seven form-control" type="tel" maxlength="1" placeholder="x"  name="tel4"  size="1" required >
                        <input class="inputs seven form-control mr1" type="tel" maxlength="1" placeholder="x"  name="tel5"  size="1" required >
                        <input class="inputs seven form-control ml1" type="tel" maxlength="1" placeholder="x"  name="tel6"  size="1" required >
                        <input class="inputs seven form-control" type="tel" maxlength="1" placeholder="x"  name="tel7"  size="1" required >
                        <input class="inputs seven form-control" type="tel" maxlength="1" placeholder="x"  name="tel8"  size="1" required >
                        <input class="inputs seven form-control" type="tel" maxlength="1" placeholder="x"  name="tel9"  size="1" required >
                        <input class="inputs seven form-control" type="tel" maxlength="1" placeholder="x"  name="tel10"  size="1" required >
                    </div>
                    <label>Enter Your Whatsapp No.</label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/whatsapp.png" alt="" /> &nbsp; +91</span>
                        </div>
                        <input class="inputs seven  form-control" type="tel" maxlength="1" placeholder="x"  name="tel11"  size="1" required >
                        <input class="inputs seven  form-control" type="tel" maxlength="1" placeholder="x"  name="tel12"  size="1" required >
                        <input class="inputs seven  form-control" type="tel" maxlength="1" placeholder="x"  name="tel13"  size="1" required >
                        <input class="inputs seven  form-control" type="tel" maxlength="1" placeholder="x"  name="tel14"  size="1" required >
                        <input class="inputs seven  form-control mr1" type="tel" maxlength="1" placeholder="x"  name="tel15"  size="1" required >
                        <input class="inputs seven  form-control ml1" type="tel" maxlength="1" placeholder="x"  name="tel16"  size="1" required >
                        <input class="inputs seven  form-control" type="tel" maxlength="1" placeholder="x"  name="tel17"  size="1" required >
                        <input class="inputs seven  form-control" type="tel" maxlength="1" placeholder="x"  name="tel18"  size="1" required >
                        <input class="inputs seven  form-control" type="tel" maxlength="1" placeholder="x"  name="tel19"  size="1" required >
                        <input class="inputs seven  form-control" type="tel" maxlength="1" placeholder="x"  name="tel20"  size="1" required >
                    </div>
                    <label>Enter Your City</label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><img src="images/map.png" alt="" /></span>
                        </div>
                        <input type="text" name="city" class="form-control" placeholder="Enter Your City">
                    </div>
                    <input type="submit" name="submit" class="form-control mb-2 btn btn-primary" value="Submit &amp; Get A Call Back ">
                </form>
            </div>
        </div>
    </div> 
</div> 
<div class="review_overlay">
    <div id="reviewten" class="review">
        <button id="closeten" class="close"><i class="fa fa-times-circle" aria-hidden="true"></i> Close</button>
        <section class="commonerror lightgrey pt-0 pb-0">
            <div class="container">
                <h3 class="main_heading">Website Integration Features</h3>
                <div class="row pt-2 pb-2">
                    <div class="col-sm-6">
                        <img src="images/integration.webp" alt="" />
                    </div>
                    <div class="col-sm-6">
                        <div class="box_inner">
                            <div class="swiper mySwiper">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <h6 class="text-center">Basic Integration Features:</h6>
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i>WhatsApp Account Integration</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Social Media Accounts Integration</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Google Map Integration</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Social Sharing Buttons</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Customer Review Platforms (Google Reviews, etc.)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with E-commerce Platforms (Shopify, WooCommerce)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Payment Gateways (PayPal, Stripe)</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                    <h6 class="text-center">Premium Integration Features:</h6>
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Google Business Listing Integration </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Google Analytics Account Integration </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Customized Live Chat Integration </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Location-Based Services (Google Maps, Store Locator) </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Booking or Appointment Scheduling System </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with CRM (Customer Relationship Management) System </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Customer Support Ticketing System </li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                    <h6 class="text-center">Basic Integration Features:</h6>
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Content Management Systems (WordPress, Drupal)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Language Translation Services</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Affiliate Marketing Platforms</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with User-generated Content Aggregators</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Data Visualization Tools</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with SMS Notification Services</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Stock Image Libraries</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <h6 class="text-center">Premium Integration Features:</h6>
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Social Media Feeds (Instagram, Facebook, etc.)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Analytics Tools to Track Website Performance</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Live Chat or Customer Support Platforms</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Video Hosting Platforms (YouTube, Vimeo)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with E-commerce Shipping and Tracking Services</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Event Management Platforms</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Job Application and Recruitment Systems</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <h6 class="text-center">Basic Integration Features:</h6>
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Online Survey and Polling Platforms </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Community and Forum Platforms </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Donation and Fundraising Platforms </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Interactive Maps and Wayfinding </li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                     <h6 class="text-center">Premium Integration Features:</h6>
                                        <ul>  
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Webinar Hosting Platforms</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Event Registration and Ticketing Systems</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Social Proof Notifications (Recent Sales, Sign-ups)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Weather Updates</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with CRM and Marketing Automation Tools</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Chatbots and AI Assistants</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Podcast Hosting and Distribution</li>
                                        </ul>
                                    </div>  
                                    <div class="swiper-slide">
                                    <h6 class="text-center">Premium Integration Features:</h6>
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Voice Assistants (Amazon Alexa, Google Assistant)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Appointment Reminders (SMS, Email)</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Social Media Advertising Platforms</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Recruitment and HR Management Systems</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with Knowledge Base and Help Center Systems</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integration with API for Custom Functionality</li>
                                        </ul>
                                    </div>                                    
                                </div>
                                <div class="swiper-button-next"></div>
                                <div class="swiper-button-prev"></div>
                                <div class="swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> 
      </div>
</div>    <div id="whyus" style="display:none">
        <div class="whyus">
            <h2 class="main_heading">WHY YOU SHOULD CHOOSE US</h2>
            <h4>(Experience the difference & Uniqueness)</h4>
                <div class="fixed_scroll">
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> We view our clients as partners, working closely with clients to understand their unique brand identity and goals, and translating them into visually appealing to achieve mutual success, and offering strategic guidance to help your business grow. Furthermore, we are committed to building long-term relationships with our clients, providing ongoing support, optimizations, and strategic guidance as your business evolves.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Our portfolio showcases a range of successful Google Ads portfolio and ability to deliver tangible results for our clients.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Proven ability to work within specified budgets, providing cost-effective solutions without compromising the client's vision and the quality of leads.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> We specialize in generating a continuous flow of qualified leads from your preferred location or target audience, helping you make the most of your business prospects.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Dedicated in-house team of highly skilled experts with a proven track record of delivering exceptional digital experiences.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> We prioritize long-term partnerships, offering continuous support, guidance, and strategic advice as supporting your business's evolution and expansion journey.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Protecting your data and ensuring its security are our top priorities. We strictly adhere to data protection regulations and implement strong measures to safeguard sensitive information. Furthermore, We maintain high ethical standards in all our business practices, ensuring transparency, honesty, and integrity throughout our interactions with clients.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Proactive Account Management: We assign dedicated account managers who proactively monitor and optimize your Google Ads campaigns to ensure they are always performing at their best.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Transparent Pricing Structure: We offer transparent pricing with no hidden costs, providing you with a clear understanding of how your budget is allocated and the value you receive.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Dedicated Support and Timely Communication: We provide dedicated support and ensure timely communication throughout the campaign lifecycle, ensuring that your questions and concerns are addressed promptly.</p>
            </div>
        </div>
    </div>
    <div id="audit" style="display:none">
        <div class="whyus">
            <h2 class="main_heading">Book Audit</h2>
                <div class="fixed_scroll">
                 <div class="book_audit d-none">
                    <form action="" method="post">
                        <div class="row">
                            <div class="col-sm-3">
                                <label>Name</label>
                                <input type="text" class="form-control" name="name" placeholder="Your Name" />
                            </div>
                            <div class="col-sm-3">
                                <label>Email</label>
                                <input type="email" class="form-control"  name="email" placeholder="Your Email" />
                            </div>
                            <div class="col-sm-3">
                                <label>Phone</label>
                                <input type="text" class="form-control"  name="phone" placeholder="Your Phone" />
                            </div>
                            <div class="col-sm-3">
                                <label>&nbsp;</label>
                                <input type="submit" class="form-control btn btn-dark"  name="submit" value="Book Aduit" />
                            </div>
                        </div>
                    </form>
                 </div>   
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Book “Audit” by ppc5G.com & unlock the secrets of unique leads generation techniques.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Examination by ppc5G.com exposes the hidden errors and unseen truths.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Google Ads account review: Evaluate the overall health and structure of your Google Ads account, identifying areas for improvement.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Where ads show up: Check if your ads are appearing in places that make sense for your audience.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Negative keywords audit: Identify irrelevant or low-converting keywords and add them as negative keywords to optimize your budget.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Website speed check: Make sure the page your ad takes people to loads quickly, so they don't get impatient and leave.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Emotional impact check: See if your ads make people feel something and how that affects what they do next.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Where people click: Use a heatmap to see where people click on your landing page, so you can make it better.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Keyword analysis: Assess the relevance and performance of your chosen keywords to refine your targeting strategy.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Ad copy effectiveness: Review your ad copy for clarity, relevance, and call-to-action effectiveness.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Ad extensions assessment: Analyze the usage and impact of ad extensions to maximize your ad's visibility and engagement.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Ad positioning assessment: Analyze the performance of your ads in different positions and adjust bids accordingly.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Landing page relevance check: Ensure that your landing pages align with your ad content to improve user experience and conversions.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Conversion tracking verification: Confirm that your conversion tracking is set up correctly to measure campaign effectiveness accurately.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Device performance analysis: Review how your ads perform on different devices and adjust bids to optimize results.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Search term analysis: Analyze search terms triggering your ads and optimize by adding negative keywords or refining your targeting.</p>
                <hr>
                <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Competitor benchmarking: Compare your ad performance with competitors to identify opportunities for improvement and differentiation.
            </div>
        </div>
    </div>
    <div id="checlistnow" style="display:none">
        <div class="whyus">
            <h2 class="main_heading">Important Information to Know Before Selecting Google Ads Company</h2>
            <div class="fixed_scroll">
                <div class="box_inner">
                    <ul>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Client Onboarding Process:</b> Inquire about how the company welcomes new clients and gathers important information about their business, goals, and target audience. A professional company will have a structured process to ensure they understand your needs and objectives from the start.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Clear Communication Channels:</b> Ensure the company has easy-to-use and efficient ways to communicate with you. They should be responsive and proactive in providing updates on how your advertising campaigns are performing and any improvements they make.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Collaboration and Transparency:</b> Look for a company that values working together with you. They should involve you in decision-making and seek your input on important matters. Additionally, they should be transparent about their strategies and explain the reasons behind their recommendations.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Data Privacy and Confidentiality:</b> Make sure the company takes data privacy seriously. They should have strong security measures in place to protect your sensitive information and comply with data protection regulations to keep your data safe.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Continuous Learning and Development:</b> Assess the company's dedication to ongoing learning. A good company will invest in training for their team to stay up-to-date with the latest industry trends, Google Ads updates, and emerging technologies to provide you with the best service.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Adherence to Industry Standards and Best Practices:</b> Verify if the company follows industry standards and best practices in managing advertising campaigns. This includes ethical advertising practices, compliance with Google policies, and keeping up with industry guidelines to maintain high-quality service.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Team Expertise:</b> Evaluate the qualifications, certifications, and experience of the company's team members. A skilled team, especially those knowledgeable in Google Ads and digital advertising, can better serve your advertising needs.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Technology and Tools:</b> Inquire about the technology and tools the company uses to manage and optimize Google Ads campaigns effectively. Having the right tools can lead to more efficient and successful campaigns.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Customization and Strategy:</b> Look for a company that tailors Google Ads strategies to fit your specific business goals and target audience. A customized approach can yield better results than a one-size-fits-all solution.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Remarketing Strategies:</b> Determine if the company effectively uses remarketing strategies to reconnect with users who have previously interacted with your website or ads. Remarketing can help reinforce your brand and increase conversions.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Analytics and Reporting:</b> Ensure the company provides detailed analytics and reporting. This allows you to monitor your campaign's performance accurately and understand how your advertising budget is being utilized.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Performance Track Record:</b> Assess the company's track record in delivering successful Google Ads campaigns. Look for key metrics like click-through rates, conversions, and return on investment (ROI) to gauge their effectiveness.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Compliance and Policies:</b> Verify that the company complies with Google Ads policies and guidelines to avoid any potential issues or penalties that could negatively impact your campaigns.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Competitive Analysis:</b> Inquire about the company's approach to conducting competitive analysis. Understanding the competitive landscape can help them create more effective strategies to outperform your rivals.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Client Portfolio:</b> Look at the company's client portfolio to see if they have experience working with reputable brands or businesses similar to yours. This can provide insights into their expertise and suitability for your needs.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Contract Terms and Exit Clauses:</b> Carefully review the contract terms, including any exit clauses. Ensure the terms align with your expectations and provide flexibility in case you need to make changes.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Pricing Structure:</b> Understand the company's pricing structure and fee breakdown to ensure it fits your budget. It's essential to know what you're paying for and how much you can expect to invest.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Industry Reputation and Recognition:</b> Research the company's reputation within the industry. Look for awards, recognition, or positive reviews that indicate their professionalism, expertise, and client satisfaction.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Long-term Relationship Focus:</b> Look for a company that prioritizes building long-term relationships with clients. They should be committed to your success and provide ongoing support, optimizations, and strategic guidance as your business evolves.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Professional Ethics:</b> Consider the company's professional ethics. They should prioritize honesty, integrity, and ethical conduct in all aspects of their work, including client interactions, reporting, and campaign management.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Proven Results and Case Studies:</b> Look for evidence of the company's success in delivering results for clients. They should provide case studies, testimonials, or references that demonstrate their ability to achieve positive outcomes for businesses like yours.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Problem-solving Approach:</b> Evaluate the company's proactive problem-solving approach. A professional company will identify challenges, offer solutions, and provide recommendations to optimize campaign performance and overcome any obstacles that arise during your collaboration.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="pagemistake" style="display:none">
        <div class="whyus">
            <h2 class="main_heading">Hidden Landing Page Mistakes by Reputable Brands that Nobody Talks About</h2>
            <div class="fixed_scroll">
                <p>The majority of advertisers struggle to convert their ad clicks into leads because they cannot create landing page experiences that generate magnet as quickly as they create ads.</p>
                <h4 class="text-center mb-0" style="font-size: 1.4rem;">You're wasting over 90% of your advertising budget if you are doing these mistakes..</h4>
                <div class="box_inner">
                    <ul>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #1</b> Your visitors don’t understand what you’re offering</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #2</b> Not using a fast hosting provider</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #3</b> Using a single conversion path</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #4</b> Too many conversion goals</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #5</b> Not using A/B testing or sometimes doing without enough data.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #6</b> Not thinking about landing page design for mobile screen size </li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #7</b> Assuming shorter forms convert better</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #8</b> Including a navigation menu and footer to distract visitor</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #9</b> Not matching ad copy with landing page copy</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #10</b> Not optimised for mobile.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #11</b> Forgetting your thank you page</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #12</b> Forgetting social proof, testimonials, certifications, reviews & etc.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #13</b> Talking like a non-human, robot & without emotions etc.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #14</b> Your landing page is loading way too slowly</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #15:</b> Showing more features than benefits</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="withexpert" style="display:none">
        <div class="whyus web5glist">
            <h2 class="main_heading">Important Discussion With Our PPC Expert Before Starting Google Ads:</h2>
            <div class="fixed_scroll">
                <div class="listpnl">
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web2" role="button" aria-expanded="false" aria-controls="web2">
                        Understanding Your Business Objectives and Goals: <i class="fa fa-minus-circle"></i>
                        </a>
                        <div class="collapse show" id="web2">
                            <p>We'll start by understanding your business's primary objectives and specific goals for running Google Ads. This helps us tailor our strategies to align perfectly with your aspirations.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web3" role="button" aria-expanded="false" aria-controls="web3">
                        Identifying Your Target Audience and Buyer Personas: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web3">
                            <p>Understanding who your target audience is and creating detailed buyer personas are essential steps in creating effective advertising campaigns. We will collaborate with you to identify your ideal customers and gather important information about them. This will help us design advertisements that truly connect with your potential customers and speak to their specific needs and preferences.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web4" role="button" aria-expanded="false" aria-controls="web4">
                        Evaluating Your Website Readiness: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web4">
                            <p>We'll check your website's suitability for ads, suggest conversion-friendly improvements, and ensure a seamless user experience to boost desired actions and campaign success.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web5" role="button" aria-expanded="false" aria-controls="web5">
                        Determining Your Budget Allocation: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web5">
                            <p>Budget management is a key aspect of running successful Google Ads campaigns. We'll discuss your budget and allocate it strategically across different campaigns and ad groups to maximize results.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web6" role="button" aria-expanded="false" aria-controls="web6">
                        Addressing Advertising Risks: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web6">
                            <p>Every advertising campaign carries potential risks. Our focus is on identifying challenges like low conversions, dangerous competition, and unpredictable outcomes. We'll propose effective strategies to minimize these risks.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web7" role="button" aria-expanded="false" aria-controls="web7">
                        Determining Your Budget Allocation: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web7">
                            <p>Budget management is a key aspect of running successful Google Ads campaigns. We'll discuss your budget and allocate it strategically across different campaigns and ad groups to maximize results.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web8" role="button" aria-expanded="false" aria-controls="web8">
                        Exploring Advertising History Across Platforms, Locations, and Conversions: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web8">
                            <p>We'll review your past advertising experiences, looking into various platforms, geographical locations, and past conversion data. This historical analysis will provide valuable insights to guide our strategies for future success.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web9" role="button" aria-expanded="false" aria-controls="web9">
                        Determining If Google Ads Fits Your Business: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web9">
                            <p>Let's analyze if Google Ads is the right fit for your business based on your profit margins with products or services. Although Many people use Google Ads, we need to check if it suits your goals and objectives.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web10" role="button" aria-expanded="false" aria-controls="web10">
                        Assessing Risks of Running Ads and Budget Spending: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web10">
                            <p>Before we begin, let's talk about the potential risks involved in running Google Ads and investing your budget. It's important to be aware of challenges like low conversions, market competition, and unpredictable outcomes.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web11" role="button" aria-expanded="false" aria-controls="web11">
                        Customer Lifetime Value (LTV) and Real Value of Conversions: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web11">
                            <p>We will explore the long-term value of your customers (LTV) and its connection to the actual value of conversions from advertising. This understanding guides us in making informed decisions and optimizing your budget wisely.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web12" role="button" aria-expanded="false" aria-controls="web12">
                        Learning from Past Marketing Efforts: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web12">
                            <p>If you've engaged in marketing before, we'll review your past experiences to learn from what worked and what didn't. This way, we can fine-tune our approach and build on successful aspects.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web13" role="button" aria-expanded="false" aria-controls="web13">
                        Addressing Your Concerns and Questions: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web13">
                            <p>We value open communication, so we'll provide ample time for you to ask any questions or express any concerns you may have about Google Ads and its management</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="consultation" style="display:none">
        <div class="whyus web5glist">
            <h2 class="main_heading">How Personalized PPC Consultation Helps You For Maximizing Success</h2>
            <div class="fixed_scroll">
                <div class="listpnl">
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web212" role="button" aria-expanded="false" aria-controls="web212">
                        Educational Guidance: <i class="fa fa-minus-circle"></i>
                        </a>
                        <div class="collapse show" id="web212">
                            <p>Our consultant provides educational consultation, explaining the basics of PPC advertising, its advantages, and how it can boost your business growth.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web312" role="button" aria-expanded="false" aria-controls="web312">
                        Confidence in Choice: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web312">
                            <p>Our consultant is to ensure you feel confident in your decision, whether to start PPC or explore other marketing avenues.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web412" role="button" aria-expanded="false" aria-controls="web412">
                        Data Analysis: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web412">
                            <p>Our consultant performs in-depth data analysis, examining your business's historical performance, market trends, and industry benchmarks to assess PPC feasibility.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web512" role="button" aria-expanded="false" aria-controls="web512">
                        Step-by-Step Support:  <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web512">
                            <p>Our consultant offers hands-on assistance, guiding you through the setup and management of PPC campaigns, ensuring a smooth and manageable process.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web612" role="button" aria-expanded="false" aria-controls="web612">
                        Platform Recommendations: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web612">
                            <p>Guiding you in selecting the most suitable PPC platforms, considering your target audience and campaign objectives.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web712" role="button" aria-expanded="false" aria-controls="web712">
                        Existing Marketing Strategy:  <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web712">
                            <p>Our Consultant review your previous and current marketing efforts to identify how PPC can complement or enhance your overall strategy.</p>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web812" role="button" aria-expanded="false" aria-controls="web812">
                        Landing Page Optimization Recommendations: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web812">
                            <p>Our consultant offers expert recommendations to optimize landing pages specifically for PPC campaigns. This ensures better user experiences and higher conversion rates, maximizing the effectiveness of your ads.</p>
                        </div>
                    </div>
                    <div class="innerlist">
                        <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web912" role="button" aria-expanded="false" aria-controls="web912">
                        Seasonal Campaign Planning: <i class="fa fa-plus-circle"></i>
                        </a>
                        <div class="collapse" id="web912">
                            <p>Based on industry trends and data analysis, our consultant advises you on seasonal PPC campaign planning. This helps you capitalize on peak periods, while avoiding unnecessary expenses during slower times.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   </div>   
    <div id="privacyctn" style="display:none">
        <div class="whyus">
            <h2 class="main_heading">Privacpy Policy</h2>
            <div class="fixed_scroll">
                
                <div class="default_ctn"> 
                    <h4>1. PRIVACY POLICY</h4>
                    <p>Web5G Technology Pvt Ltd, recognized as a Private Limited company, maintains its official presence at <a href="https://ppc5g.com/">www.ppc5g.com</a> on the web and using it as an online address.</p>
                    <p>At Web5G Technology Pvt Ltd, accessible from <a href="https://ppc5g.com/">www.ppc5g.com</a>, finding the customers who are interested in PPC & Google Ads Managment Services </p>
                    <p>This Privacy Policy document contains types of information that is collected and recorded by Web5G Technology Pvt Ltd company, and how we use it.</p>
                    <hr>
                    <h4>2. WHY THIS PRIVACY POLICY</h4>
                    <ul style="list-style:none; padding-left:0;">
                        <li>2.1 We want you to feel comfortable using our website.</li>
                        <li>2.2 We want you to feel secure submitting information to this website.</li>
                        <li>2.3 We want you to contact us with your questions or concerns about privacy on this website.</li>
                        <li>2.4 We want you to know that by using our website you are consenting to the collection of certain data.​</li>
                    </ul>
                    <p>This Privacy Policy applies only to our online activities and is valid for visitors to our website with regards to the information that they shared and/or collected in PPC5gTechnology Pvt Ltd.</p>
                    <p><b>Note:</b> This policy is not applicable to any information collected offline or via channels other than this website. If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.</p>
                    <hr>
                    <h4>3. HOW TO CONTACT US</h4>
                    <p>For all queries or issues relating to the collection or processing of your personal information by us If you have any questions regarding this Privacy Policy or the way we use your personal information, you can contact us by e-mail or telephone or by mail to:</p>
                    <p>If you have any questions about this Privacy Policy, You can contact us:</p>
                    <ul>
                        <li><b>By email:</b> <a href="mailto:info@ppc5g.com">info@ppc5g.com</a></li>
                        <li><b>By phone number</b><a href="tel:9999123123">+91 9999-123-123</a></li>
                        <li><b>By visiting at address:</b> 626, 6th Floor, Signature Global Mall, Sector - 3, Vaishali, Ghaziabad, Uttar Pradesh -201010</li>
                    </ul>
                    <hr>
                    <h4>4. CONSENT POLICY</h4>
                    <p>By using our website, you hereby consent to our privacy policy and agree to its terms.</p>
                    <p>The personal information that you are asked to provide, and the reasons why you are asked to provide it, will be made clear to you at the point we ask you to provide your personal information.</p>
                    <p>If you contact us directly, we may receive additional information about you such as your name, email address, phone number, the contents of the message and/or attachments you may send us, and any other information you may choose to provide.</p>
                    <hr>
                    <h4>5. DATA PRIVACY AND SECURITY</h4>
                    <p>We prioritize the privacy and security of user data and implement appropriate measures to protect personal information.</p>
                    <p>While using our service, We may ask you to provide us with certain personally identifiable information that can be used to contact or identify you. Personally identifiable information may include, but is not limited to:</p>
                    <p><b>5.1 Types of Data Collected:</b></p>
                    <ul>
                        <li>Email address</li>
                        <li>First name and last name</li>
                        <li>Phone number</li>
                        <li>Address, State, Province, ZIP/Postal code, City</li>
                    </ul>
                    <p><b>5.2 How Long Will We Keep Your Personal Information?</b></p>
                    <p>We will retain your personal information for no longer than is necessary for the purposes for which the personal information is processed. The length of time we hold on to your personal information will vary according to what that information is and the reason for which it is being processed.</p>
                    <p>To decide how long we should keep your personal information, we consider factors such as the kind of information, how sensitive it is, the risk of unauthorized use or disclosure, why we collect it, and if there are other ways to achieve our goals.</p>
                    <hr>
                    <h4>6. DATA SECURITY</h4>
                    <p>We have implemented security measures to safeguard your personal information.</p>
                    <p>These measures aim to prevent accidental loss, unauthorized access, alteration, or disclosure of your information. Access to your personal information is limited to individuals and entities who have a legitimate business need to know.</p>
                    <p>For more information about the specific security measures we have in place, you can contact us at any point of time.</p>
                    <hr>
                    <h4>7. YOUR RIGHTS</h4>
                    <p>The rights may only apply in certain circumstances and are subject to certain exemptions. Please see the table below for a summary of your rights. You can exercise these rights using the contact details below.</p>
                    <p><b>7.1 Right of Access to Your Personal Information:</b></p>
                    <p>You have the right to receive a copy of your personal information that we hold about you, subject to certain exemptions.</p>
                    <p>We may require further information in order to respond to your request (for instance, evidence of your identity and information to enable us to locate the specific personal information you require).</p>
                    <p><b>7.2 Right to Rectify Your Personal Information:</b></p>
                    <p>You have the right to ask us to correct your personal information that we hold where it is incorrect or incomplete.</p>
                    <p><b>7.3 Right to Erasure of Your Personal Information:</b></p>
                    <p>You have the right to ask that your personal information be deleted in certain circumstances.<br> <b>For example:</b> </p>
                    <ul>
                        <li>Where your personal information is no longer necessary in relation to the purposes for which they were collected or otherwise used;</li>
                        <li>if you withdraw your consent and there is no other legal ground for which we rely on for the continued use of your personal information;</li>
                        <li>if you object to the use of your personal information (as set out below);</li>
                        <li>if we have used your personal information unlawfully; or</li>
                        <li>if your personal information needs to be erased to comply with a legal obligation.</li>
                    </ul>
                    <p><b>7.4 Right to Restrict The Use of Your Personal Information:</b></p>
                    <p>You have the right to put on hold to use your personal information in certain circumstances. <br> <b>For example:</b></p>
                    <ul>
                        <li>Where you think your personal information is inaccurate and only for such a period to enable us to verify the accuracy of your personal information</li>
                        <li>We no longer need your personal information, but your personal information is required by you for the establishment, exercise or defence of legal claims; or</li>
                    </ul>
                    <p><b>7.5 Right to Withdraw Consent:</b></p>
                    <p>You have the right to withdraw your consent at any time where we rely on consent to use your personal information.</p>
                    <p><b>7.6 Right to Complain to The Relevant Data Protection Authority:</b></p>
                    <p>You have the right to complain to the relevant Data Protection Authority where you think we have not used your personal information in accordance with data protection law</p>
                    <hr>
                    <h4>8. NO ASSOCIATION WITH RELEVANT BRANDS AND COMPANIES</h4>
                    <p>This landing page is not associated with or endorsed by the relevant brands and companies mentioned. The use of their names, logos, trademarks, or images is for descriptive purposes only and does not imply any affiliation or endorsement.</p>
                    <hr>
                    <h4>9. NO PARTNERSHIP OR ENDORSEMENT</h4>
                    <p>The presence of other brands, logos, or trademarks on this landing page does not imply partnership, endorsement, or affiliation unless explicitly stated.</p>
                    <hr>
                    <h4>10. TRANSPARENT COMMUNICATION</h4>
                    <p>We maintain transparent communication with brand owners to ensure compliance and resolve any concerns regarding the content on this landing page.</p>
                    <hr>
                    <h4>11. NO COUNTERFEIT PRODUCTS</h4>
                    <p>We do not promote or sell counterfeit or unauthorized products on this landing page.</p>
                    <hr>
                    <h4>12. OUR OPERATIONS INVOLVE THE USE OF THIRD-PARTY VENDORS:</h4>
                    <p><b>12.1 Google Ads (AdWords) remarketing service is provided by Google Inc</b></p>
                    <ul>
                        <li>You can opt-out of Google Analytics for Display Advertising and customise the Google Display Network ads by visiting the Google Ads Settings page: http://www.google.com/settings/ads</li>
                        <li>Google also recommends installing the Google Analytics Opt-out Browser Add-on – https://tools.google.com/dlpage/gaoptout – for your web browser. Google Analytics Opt-out Browser Add-on provides visitors with the ability to prevent their data from being collected and used by Google Analytics.</li>
                        <li>For more information on the privacy practices of Google, please visit the Google Privacy & Terms web page: https://policies.google.com/privacy</li>
                    </ul>
                    <p><b>12.2 Analytics</b></p>
                    <ul>
                        <li>We may use third-party Service providers to monitor and analyze the use of our Service.</li>
                        <li>Google Analytics is a web analytics service offered by Google that tracks and reports website traffic. Google uses the data collected to track and monitor the use of our Service. This data is shared with other Google services. Google may use the collected data to contextualize and personalize the ads of its own advertising network.</li>
                        <li>For more information on the privacy practices of Google, please visit the Google Privacy & Terms web page: https://policies.google.com/privacy</li>
                    </ul>
                    <hr>
                    <h4>13. CHILDREN’S PRIVACY</h4>
                    <p>Our Services are not intended for use by children under the age of 18 (“Child” or “Children”). We do not knowingly collect personally identifiable information from Children under 18. If you become aware that a Child has provided us with Personal Data, please contact us. </p>
                    <hr>
                    <h4>Contact Us</h4>
                    <ul>
                        <li><b>By email:</b> <a href="mailto:info@ppc5g.com">info@ppc5g.com</a></li>
                        <li><b>By phone number</b><a href="tel:9999123123">+91 9999-123-123</a></li>
                        <li><b>By visiting at address:</b> 626, 6th Floor, Signature Global Mall, Sector - 3, Vaishali, Ghaziabad, Uttar Pradesh -201010</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="whyclients" style="display:none">
        <div class="whyus">
            <h2 class="main_heading">Reasons Why Clients Love Us?</h2>
            <div class="fixed_scroll">
                <div class="box_inner">
                    <ul>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Our clients love us because we have a proven track record of delivering successful Google Ads campaigns that drive tangible results.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> They appreciate our expertise in Google Ads, knowing that we stay up-to-date with the latest industry trends and best practices.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Our clients love us because we prioritize understanding their unique business needs and goals, tailoring our Google Ads strategies accordingly.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> They value the personalized attention and support provided by our dedicated account managers, personalized attention and consistent communication and supportive relationships.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Conversion-Driven Campaigns: Our focus on driving conversions, not just clicks, ensures that clients' ad spend generates tangible profits, contributing directly to their business goals.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Click Fraud Prevention: Implementing robust measures to prevent click fraud safeguards our clients' budget, ensuring their ad spend is used efficiently. Our clients love us because our click fraud prevention measures that protect their budgets and give them peace of mind.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Problem-solving Approach: Our proactive mindset identifies challenges and offers prompt solutions to optimize campaign performance. Our clients love us because of our proactive approach, offering strategic recommendations and optimizations for continuous improvement.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> They trust our data-driven decision-making, as we utilize advanced analytics and insights to optimize campaigns effectively.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Profit-Focused Bid Management: By employing profit-focused bid management techniques, we optimize bids based on revenue potential, helping clients achieve their profit targets.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Clients appreciate that we take the time to understand their target audience and industry, ensuring that their ads reach the right people at the right time.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> They value our expertise in landing page optimization, which ensures a seamless user experience and leads to higher conversion rates.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Continuous Monitoring: Our round-the-clock monitoring enables swift responses to changes and real-time campaign optimization, maximizing profitability. Our continuous monitoring and real-time optimizations keep our clients' campaigns ahead of the competition.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Clients love our in-depth competitor analysis, which gives them a competitive edge in the Google Ads landscape.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Our commitment to ethical practices and compliance reassures clients that their brand reputation is safe with us.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Our clients love us because we prioritize their long-term success, focusing on sustainable growth rather than short-term gains.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="exclusiveppc" style="display:none">
        <div class="whyus">
            <h2 class="main_heading">Exclusive PPC Additional Services That Provide Extra Value</h2>
            <div class="fixed_scroll">
                <div class="box_inner">
                    <ul>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Conversion Funnel Optimization:</b> Analyzing and optimizing the entire conversion funnel, from ad click to final conversion, to maximize conversion rates and ROI.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ad Compliance Monitoring:</b> Ensuring ad campaigns comply with advertising policies and guidelines set by Google Ads and industry-specific regulations.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>CRM Retargeting:</b> Integrating Google Ads with client CRM systems to retarget ads specifically to users who have engaged with the client's brand or products.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Advanced Retargeting Strategies:</b> Developing advanced retargeting strategies, such as sequential retargeting, dynamic product retargeting, or cross-channel retargeting, to re-engage users and drive conversions.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Customer Data Integration:</b> Integrating clients' customer data, such as CRM data or offline purchase data, into Google Ads to enhance targeting, personalization, and measurement capabilities.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ad Spend Forecasting:</b> Providing clients with accurate ad spend forecasts based on historical data, market trends, and campaign goals to aid in budget planning.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Local Business Listing Optimization:</b> Optimizing clients' local business listings on platforms like Google My Business to improve visibility in local search results.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Google Analytics Audit and Insights:</b> Conducting thorough audits of clients' Google Analytics accounts, providing actionable insights to improve tracking and reporting accuracy.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Customer Journey Mapping:</b> Mapping out the customer journey across various touchpoints and channels to identify opportunities for ad placement and messaging.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ad Landing Page Speed Optimization:</b> Analyzing and optimizing landing page load times to improve user experience, reduce bounce rates, and increase conversions.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Google Tag Manager Setup and Optimization:</b> Setting up and managing Google Tag Manager to streamline the implementation of tracking codes and tags across websites.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Advanced Audience Segmentation:</b> Utilizing advanced segmentation techniques, such as lookalike audiences and customer segmentation based on behavior and interests, for more precise targeting.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Ad Fraud Detection and Prevention:</b> Implementing advanced ad fraud detection systems and processes to protect clients' ad budgets from fraudulent activities.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Lifetime Value (LTV) Optimization:</b> Implementing strategies to optimize campaigns based on the projected lifetime value of customers, considering factors such as repeat purchases, cross-selling, and upselling opportunities.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> <b>Advanced Bid Strategy Development:</b> Creating customized bid strategies based on specific business objectives, such as maximizing conversion volume, maintaining target ROAS (return on ad spend), or achieving top ad positions.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="typeads" style="display:none">
        <div class="whyus">
            <h2 class="main_heading">Types of ads we are expertise</h2>
            <div class="fixed_scroll">
                <div class="box_inner">
                    <ul>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Search Text Ads: Craft targeted text ads to appear at the top of Google search results, driving users actively seeking your products or services.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Display Banner Ads: Develop visually captivating banners for the Google Display Network, effectively showcasing your offerings to a wider audience.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Remarketing Ads: Strategically re-engage past visitors with tailored ads across the web to bring them back to your site and convert.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Gmail Sponsored Promotions (GSP): Employ interactive Gmail ads to engage potential leads in their inbox, fostering direct communication.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Shopping Ads: Utilize Google Shopping to display product images, prices, and details, enticing users to make purchase decisions.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Local Search Ads: Boost local visibility by running ads that target users searching for businesses in your area.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Call-Only Ads: Drive phone inquiries directly by encouraging users to call your business with a single click.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Responsive Search Ads: Optimize ad performance with flexible ads that adapt to different platforms and user preferences.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Portfolio Bid Strategies: We organize your campaigns smartly to optimize their performance. By using data-driven algorithms, we adjust bids across groups of campaigns to achieve specific goals like getting more sales or better returns on investment.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Smart Bidding: We use Smart Bidding to make your ads work smarter. With the help of advanced technology, we automatically adjust how much we bid for ads based on factors like where people are and when they're looking. This way, we get you more business while keeping costs in control.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> App Promotion Ads: We create ads that help more people discover and use your app. We make sure your ads are shown to the right audience, whether they're looking for something similar or they've already shown interest.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Lead Generation Ads: Our ads make it easy for interested people to connect with you. We add forms directly into the ads so users can easily get in touch, saving them time and helping you gather valuable leads.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> CPLA (Cost Per Lead Action) Campaigns: We set up ads that make sure you only pay when users take valuable actions like signing up or requesting information. This means you're only investing in potential customers.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Ad Customizers: We customize your ads to make them more engaging. Our ads change in real-time to show relevant info like prices or limited-time offers, making users more likely to click and convert.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Conversion Optimizer: We fine-tune your ads to get more results for your budget. By analyzing past data, we adjust how much we're willing to spend on different keywords to get you more of what you want – conversions.</li>
                        <li><i class="fa fa-check" aria-hidden="true"></i> Responsive Display Ads: We design ads that look great everywhere. No matter where they're shown, our ads adapt to fit the space perfectly, making sure your message gets across clearly.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="webwhyus" style="display:none">
        <div class="whyus">
            <h2 class="main_heading">Why Choose “Website 5G” for Your Web Design Needs</h2>
                <div class="fixed_scroll">
                    <h4>At “Website 5G”, we believe in delivering a unique and exceptional experience to our clients. Our commitment to transparency, expertise, and customer satisfaction sets us apart as the premier choice for your web design needs. Here's why you should choose us</h4>
                    <p><b>Transparent Agreements:</b> We value open communication. Our written agreements cover all aspects of the project, ensuring clarity and mutual understanding.</p>
                    <hr>
                    <p><b>Proven Portfolio:</b>  With an extensive portfolio of successful projects, we showcase our history of excellence and creativity.</p>
                    <hr>
                    <p><b>Budget-Friendly Solutions:</b> We specialize in delivering cost-effective design solutions without compromising quality, making your investment worthwhile.</p>
                    <hr>
                    <p><b>Easy Selection Process:</b> Our designer themes and features/functionality checklist make the selection process a breeze.</p>
                    <hr>
                    <p><b>Cost-Saving Alternatives:</b> We're experts at finding ways to save costs while respecting your choices and preferences.</p>
                    <hr>
                    <p><b>In-House Expert Team:</b> The Website 5G team consists of skilled web designers with a track record of success.</p>
                    <hr>
                    <p><b>Tailored Designs:</b> We deeply understand your needs and goals, resulting in custom-made website designs.</p>
                    <hr>
                    <p><b>Complex Projects Made Easy:</b> Our efficiency shines in handling even the most complex projects with professionalism.</p>
                    <hr>
                    <p><b>Latest Industry Trends:</b> Stay ahead with our knowledge of the latest trends and best practices in website design.</p>
                    <hr>
                    <p><b>Thorough Documentation:</b> All project details and discussions are meticulously documented for your peace of mind.</p>
                    <hr>
                    <p><b>Responsive Design:</b> Your website will perform flawlessly across devices and screen sizes. Regular Maintenance: We ensure your website operates seamlessly with regular updates and maintenance.</p>
                    <hr>
                    <p><b>Collaborative Approach:</b> You're involved throughout the process to ensure your expectations are met.</p>
                    <hr>
                    <p><b>Clear Communication:</b> Timelines, updates, and potential delays are communicated openly and honestly.</p>
                    <hr>
                    <p><b>Client Testimonials:</b> We're proud to share references and past client experiences to showcase our track record.</p>
                    <hr>
                    <p><b>Expert Team:</b> Learn about our team's qualifications, expertise, and experience, gaining confidence in our capabilities.</p>
                    <hr>
                    <p><b>Accountability:</b> We take responsibility for mistakes and proactively work to find solutions. Personalized Solutions: Our designs are tailored to your unique needs and preferences. Years of Experience: With a history of successful projects, our industry experience speaks for itself.</p>
                    <hr>
                    <p><b>Exceptional Customer Service:</b> Your satisfaction is our priority; exceptional customer service is our guarantee.</p>
                    <hr>
                    <p><b>Scalability:</b> No project is too big or too small; we handle them all with equal dedication. Timely Delivery: Our track record proves our commitment to completing projects on time. Positive Reputation: Our strong reputation and client testimonials highlight our commitment to excellence.</p>
                    <hr>
                    <p><b>Post-Project Support:</b> We're here for the long haul, offering ongoing support and maintenance services.</p>
                    <hr>
                    <p><b>Transparent Costs:</b> Understand and control your expenses with our clear cost breakdowns. Hosting Recommendations: Benefit from our cost-effective hosting and domain registration suggestions.</p>
                    <hr>
                    <p><b>Long-Term Partnership:</b> We're in it for the long run, providing affordable maintenance for lasting cost-efficiency.</p>
                    <hr>
                    <p>Experience the Website 5G difference. Choose us for a web design journey that prioritizes your vision, needs, and success.</p>
                </div>
            </div>
        </div>
    </div>
    <div id="webpagelistname" style="display:none">
        <ul class="nav nav-tabs mob-designtab" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="checklist-tab" data-bs-toggle="tab" data-bs-target="#checklist" type="button" role="tab" aria-controls="home" aria-selected="true">Checklist</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="explore-tab" data-bs-toggle="tab" data-bs-target="#explore" type="button" role="tab" aria-controls="explore" aria-selected="false">Explore More</button>
            </li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane active" id="checklist" role="tabpanel" aria-labelledby="checklist-tab">
                <div class="whyus">
                    <h2 class="main_heading">Web Page Names in Checklist Format</h2>
                    <h4>Remember that this is a creative exercise, and you can customize it further based on your specific needs and goals.</h4>
                    <div class="fixed_scroll">      
                        <div class="webpage">
                            <h3>Page 1-10: Essential Pages</h3>
                            <ul>
                                <li><b>Page 1:</b> Home Page</li>
                                <li><b>Page 2:</b> Services/Products</li>
                                <li><b>Page 3:</b> Packages/Prices</li>
                                <li><b>Page 4:</b> Portfolio/Projects</li>
                                <li><b>Page 5:</b> Clients/Partners</li>
                                <li><b>Page 6:</b> Gallery/Photo Album</li>
                                <li><b>Page 7:</b> Landing Page</li>
                                <li><b>Page 8:</b> Video Library</li>
                                <li><b>Page 9:</b> FAQ (Question & Answer)</li>
                                <li><b>Page 10:</b> Our Team/Professionals</li>
                            </ul>
                        </div>
                        <div class="webpage">
                            <h3>Page 11-20: Core Information</h3>
                            <ul>
                                <li><b>Page 11:</b> About Us</li>
                                <li><b>Page 12:</b> Contact Us</li>
                                <li><b>Page 13:</b> Privacy Policy (Terms of Service/Legal Disclaimers)</li>
                                <li><b>Page 14:</b> Thank You or Confirmation Page</li>
                                <li><b>Page 15:</b> Coming Soon/Under Construction</li>
                                <li><b>Page 16:</b> Careers/Jobs</li>
                                <li><b>Page 17:</b> Events/Calendar</li>
                                <li><b>Page 18:</b> Error/404 Page</li>
                                <li><b>Page 19:</b> Downloadable Resources</li>
                                <li><b>Page 20:</b> Support/Help Center</li>
                            </ul>
                        </div>
                        <div class="webpage">
                            <h3>Page 21-30: Engagement and Interaction</h3>
                            <ul>
                                <li><b>Page 21:</b> Events/Workshops</li>
                                <li><b>Page 22:</b> Blogs/News</li>
                                <li><b>Page 23:</b> Special Offers</li>
                                <li><b>Page 24:</b> Limited-Time Deals</li>
                                <li><b>Page 25:</b> Discount Coupons</li>
                                <li><b>Page 26:</b> Promotional Events</li>
                                <li><b>Page 27:</b> Seasonal Sales</li>
                                <li><b>Page 28:</b> Flash Sales</li>
                                <li><b>Page 29:</b> Rewards Program</li>
                                <li><b>Page 30:</b> Refer-a-Friend Program</li>
                            </ul>
                        </div>
                        <div class="webpage">
                            <h3>Page 31-40: Education and Resources</h3>
                            <ul>
                                <li><b>Page 31:</b> Blog</li>
                                <li><b>Page 32:</b> Articles</li>
                                <li><b>Page 33:</b> Tutorials/Guides</li>
                                <li><b>Page 34:</b> How-to Videos</li>
                                <li><b>Page 35:</b> Ebooks/Whitepapers</li>
                                <li><b>Page 36:</b> Infographics</li>
                                <li><b>Page 37:</b> Webinars/Webcasts</li>
                                <li><b>Page 38:</b> Podcasts</li>
                                <li><b>Page 39:</b> Online Courses</li>
                                <li><b>Page 40:</b> Resources Directory</li>
                            </ul>
                        </div>
                        <div class="webpage">
                            <h3>Page 41-50: Social Engagement</h3>
                            <ul>
                                <li><b>Page 41:</b> Social Media Links</li>
                                <li><b>Page 42:</b> Social Media Feeds</li>
                                <li><b>Page 43:</b> Community Forum</li>
                                <li><b>Page 44:</b> User-generated Content</li>
                                <li><b>Page 45:</b> Customer Showcase</li>
                                <li><b>Page 46:</b> Live Chat/Instant Messaging</li>
                                <li><b>Page 47:</b> Discussion Boards</li>
                                <li><b>Page 48:</b> Ask the Experts</li>
                                <li><b>Page 49:</b> Feedback/Testimonials</li>
                                <li><b>Page 50:</b> FAQs and Answers</li>
                            </ul>
                        </div>
                        <div class="webpage">
                            <h3>Page 51-60: User Experience and Account</h3>
                            <ul>
                                <li><b>Page 51:</b> User Registration</li>
                                <li><b>Page 52:</b> Login/Sign In</li>
                                <li><b>Page 53:</b> User Profile</li>
                                <li><b>Page 54:</b> Account Settings</li>
                                <li><b>Page 55:</b> Order History</li>
                                <li><b>Page 56:</b> Wishlist</li>
                                <li><b>Page 57:</b> Shopping Cart</li>
                                <li><b>Page 58:</b> Checkout Page</li>
                                <li><b>Page 59:</b> Subscription Management</li>
                                <li><b>Page 60:</b> Download History</li>
                            </ul>
                        </div>
                        <div class="webpage">
                            <h3>Page 61-70: Legal and Compliance</h3>
                            <ul>
                                <li><b>Page 61:</b> Terms of Service</li>
                                <li><b>Page 62:</b> Privacy Policy</li>
                                <li><b>Page 63:</b> Cookie Policy</li>
                                <li><b>Page 64:</b> GDPR Compliance</li>
                                <li><b>Page 65:</b> COPPA Compliance</li>
                                <li><b>Page 66:</b> Accessibility Statement</li>
                                <li><b>Page 67:</b> Copyright Notice</li>
                                <li><b>Page 68:</b> DMCA Policy</li>
                                <li><b>Page 69:</b> Return/Refund Policy</li>
                                <li><b>Page 70:</b> Data Protection Policy</li>
                            </ul>
                        </div>
                        <div class="webpage">
                            <h3>Page 71-80: Localization and Languages</h3>
                            <ul>
                                <li><b>Page 71:</b> Language Selection</li>
                                <li><b>Page 72:</b> Multilingual Content</li>
                                <li><b>Page 73:</b> Currency Converter</li>
                                <li><b>Page 74:</b> International Shipping</li>
                                <li><b>Page 75:</b> Regional Pricing</li>
                                <li><b>Page 76:</b> Localized Contact Information</li>
                                <li><b>Page 77:</b> Language Preferences</li>
                                <li><b>Page 78:</b> Region-specific Policies</li>
                                <li><b>Page 79:</b> Translations</li>
                                <li><b>Page 80:</b> Currency Converter</li>
                            </ul>
                        </div>
                        <div class="webpage">
                            <h3>Page 81-90: Media and Downloads</h3>
                            <ul>
                                <li><b>Page 81:</b> Audio Tracks</li>
                                <li><b>Page 82:</b> Video Tutorials</li>
                                <li><b>Page 83:</b> High-Resolution Images</li>
                                <li><b>Page 84:</b> Media Kits</li>
                                <li><b>Page 85:</b> Software Downloads</li>
                                <li><b>Page 86:</b> Product Manuals</li>
                                <li><b>Page 87:</b> Press Releases</li>
                                <li><b>Page 88:</b> Logos/Branding Assets</li>
                                <li><b>Page 89:</b> Stock Photos</li>
                                <li><b>Page 90:</b> Mobile App Downloads</li>
                            </ul>
                        </div>
                        <div class="webpage">
                            <h3>Page 91-100: Miscellaneous</h3>
                            <ul>
                                <li><b>Page 91:</b> Site Map</li>
                                <li><b>Page 92:</b> Feedback/Contact Form</li>
                                <li><b>Page 93:</b> Test and Debugging</li>
                                <li><b>Page 94:</b> Accessibility Testing</li>
                                <li><b>Page 95:</b> A/B Testing</li>
                                <li><b>Page 96:</b> Site Search</li>
                                <li><b>Page 97:</b> RSS Feed</li>
                                <li><b>Page 98:</b> Site Analytics</li>
                                <li><b>Page 99:</b> Social Sharing Buttons</li>
                                <li><b>Page 100:</b> Maintenance Mode</li>
                            </ul>
                        </div>
                        <p><b>Feel free to adjust the order based on your specific priorities and business needs.</b></p>
                    </div>
                </div>
            </div>
            <div class="tab-pane" id="explore" role="tabpanel" aria-labelledby="explore-tab">
                <div class="whyus">
                    <h2 class="main_heading">Explore More</h2>
                    <h4>Understanding the Various Meanings Behind Web Page Types</h4>
                    <div class="fixed_scroll">      
                        <div class="webpage">
                            <ul>
                                <li><b>Home Page:</b> The primary entry point of the website, offering an overview and navigation to other sections. Also known as the main page that introduces the website and provides a glimpse of its content and purpose.</li>
                                <li><b>About Us Page:</b> This page presents a brief history of the organization or business behind the website, including the mission, values, and key team members.</li>
                                <li><b>Products/Services Page:</b> Showcasing the products or services offered by the website, including detailed descriptions, high-quality visuals, pricing details, and customer reviews.</li>
                                <li><b>Testimonials Page:</b> Displaying customer reviews and testimonials to establish credibility and trust among potential customers.</li>
                                <li><b>FAQ Page:</b> Offering answers to frequently asked questions about the website, products, services, and policies.</li>
                                <li><b>Contact Us Page:</b> Providing contact information such as phone numbers, email addresses, and physical locations for users to get in touch.</li>
                                <li><b>Blog Page:</b> Featuring blog posts relevant to the website's niche or industry, offering informative and engaging content.</li>
                                <li><b>Events Page:</b> Highlighting upcoming events related to the website's focus, such as conferences, webinars, or workshops.</li>
                                <li><b>Careers Page:</b> Sharing job postings, career opportunities, and insights into the organization's culture.</li>
                                <li><b>Press Page:</b> Showcasing press releases, media coverage, and other publicity-related materials.</li>
                                <li><b>Privacy Policy Page:</b> Detailing the organization's privacy policy and how user data is collected, stored, and used.</li>
                                <li><b>Terms and Conditions Page:</b> Outlining the terms of use, disclaimers, warranties, and liabilities related to the website's services.</li>
                                <li><b>Accessibility Page:</b> Providing information on how the website accommodates users with disabilities.</li>
                                <li><b>Sitemap Page:</b> Offering an overview of the website's structure to help users navigate between different pages.</li>
                                <li><b>Thank You Pages:</b> Displayed after users complete actions like making a purchase or submitting a form, expressing gratitude and encouraging further engagement.</li>
                                <li><b>404 Page:</b> Appearing when users reach non-existent pages, guiding them back to relevant content.</li>
                                <li><b>Pricing Page:</b> Displaying pricing information for products or services, along with any promotions or discounts.</li>
                                <li><b>Checkout Page:</b> Allowing secure and user-friendly purchases or transactions with clear instructions.</li>
                                <li><b>My Account Page:</b> Enabling registered users to view their account information, order history, and personalized content.</li>
                                <li><b>User Dashboard Page:</b> Allowing registered users to manage account settings, preferences, and other personalized features.</li>
                                <li><b>Portfolio/Gallery:</b> Showcasing past work, projects, or products through images, videos, or case studies.</li>
                                <li><b>Team/Staff:</b> Providing information about the team members or staff behind the organization.</li>
                                <li><b>Login/Sign Up:</b> Facilitating user registration or login processes.</li>
                                <li><b>Knowledge Base:</b> Offering a database of helpful articles, tutorials, or FAQs</li>
                                <li><b>Support/Help Center:</b> Providing customer support information, guides, and troubleshooting resources.</li>
                                <li><b>Community/Forum:</b> Creating a space for users to interact, ask questions, and engage in discussions.</li>
                                <li><b>Case Studies:</b> Presenting detailed success stories or examples of how the organization's offerings have benefited clients.</li>
                                <li><b>Client Portal:</b> A secure area allowing clients to access specific information or documents.</li>
                                <li><b>Partnerships/Affiliates:</b> Offering information about partnership opportunities or affiliate programs.</li>    
                                <li><b>Returns/Refunds:</b> Explaining the organization's policies regarding returns, refunds, or exchanges.</li>    
                                <li><b>Resources Directory:</b> Curating a list of external resources, tools, or websites.</li>    
                                <li><b>Support Tickets:</b> Providing a dedicated system for users to submit and track support tickets.</li>    
                                <li><b>Social Responsibility:</b> Highlighting the organization's sustainability efforts or social initiatives.</li>    
                                <li><b>Success Stories:</b> Detailing success stories related to projects or outcomes.</li>    
                                <li><b>Awards/Accolades:</b> Displaying awards, certifications, or recognition received by the organization.</li>    
                                <li><b>Research/White Papers:</b> Publishing research findings or whitepapers relevant to the industry.</li>    
                                <li><b>Community Guidelines:</b> Providing guidelines for participating in discussions or community interactions.</li>    
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="webdesigncategory" style="display:none">
        <div class="whyus">
            <h2 class="main_heading">Check out the wide range of "Web-Designing" categories!</h2>
            <div class="fixed_scroll">      
                <div class="webpage">
                    <ul>
                        <li><b>Static Websites:</b> These websites are simple and consist of fixed content. They are easy to create and suitable for small businesses or individuals who need a basic online presence.</li>
                        <li><b>Dynamic Websites:</b> Dynamic websites have dynamic content and can be updated regularly. They often have content management systems (CMS) that allow website owners to make changes easily.</li>
                        <li><b>E-commerce Websites:</b> E-commerce websites are designed for online businesses that sell products or services. They have features like shopping carts, payment gateways, and product catalogs.</li>
                        <li><b>Single-Page Websites:</b> These websites consist of only one page and are ideal for presenting concise information or a specific product/service.</li>
                        <li><b>Multi-Page Websites:</b> Multi-page websites have multiple interconnected pages that allow for more extensive content and navigation.</li>
                        <li><b>Responsive Websites:</b> Responsive design ensures that the website adapts and looks great on various devices, such as desktops, tablets, and mobile phones.</li>
                        <li><b>Mobile-First Websites:</b> Mobile-first design prioritizes the mobile user experience, ensuring the website is optimized for mobile devices.</li>
                        <li><b>Corporate Websites:</b> Corporate websites represent businesses and are designed to showcase their products, services, and company information professionally.</li>
                        <li><b>Portfolio Websites:</b> Portfolio websites are used by individuals, such as artists, photographers, and designers, to showcase their work.</li>
                        <li><b>Blog Websites:</b> Blog websites are designed for content publishing, and they typically have a chronological arrangement of articles or posts.</li>
                        <li><b>Landing Pages:</b> Landing pages are designed for specific marketing campaigns or promotions and aim to convert visitors into leads or customers.</li>
                        <li><b>Infographic Websites:</b> Infographic websites use visual storytelling and data visualization to convey information effectively.</li>
                        <li><b>Magazine-Style Websites:</b> These websites have a layout similar to magazines, with a focus on displaying various content types, such as articles, images, and videos.</li>
                        <li><b>Educational Websites:</b> Educational websites offer learning materials, courses, and resources for students and educators.</li>
                        <li><b>Non-Profit Websites:</b> Non-profit websites aim to raise awareness and support for a cause or organization, often including donation options.</li>
                        <li><b>Personal Websites:</b> Personal websites are created by individuals to share personal information, blogs, portfolios, or resumes.</li>
                        <li><b>Product Showcase Websites:</b> Product showcase websites are used to display and promote a specific product or service.</li>
                        <li><b>Membership Websites:</b> Membership websites offer exclusive content or services to registered members who have paid for access.</li> 
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="clickwebsite" style="display:none">
        <div class="whyus">
            <h2 class="main_heading">List of Features and Functionalities Used in Website Design</h2>
            <div class="fixed_scroll">      
                <div class="webpage">
                    <h3>Basic Features</h3>
                    <ul>
                        <li>Fast Loading Website Speed</li>
                        <li>Mobile Speed Without Lazy Loading</li>
                        <li>Multi-language Support</li>
                        <li>Sitemap for Easy Navigation and SEO</li>
                        <li>User-friendly Interface</li>
                        <li>Integrated Social Media Sharing</li>
                        <li>Cross-Device Compatibility</li>
                        <li>Effective Call-to-Action Elements</li>
                        <li>GDPR Compliance and Privacy Controls</li>
                        <li>Content Version Control</li>
                        <li>Data Encryption and Protection</li>
                        <li>Seamless Third-Party Integrations</li>
                        <li>Dynamic Video Galleries</li>
                        <li>User-generated Content Showcasing</li>
                        <li>Instant Content Translation</li>
                    </ul>
                </div>
                <div class="webpage">
                    <h3>Premium Features</h3>
                    <ul>
                        <li>Premium Security Features (SSL certificate)</li>
                        <li>Advanced Search Functionality</li>
                        <li>Multi-language Support for International Audiences</li>
                        <li>AI-Powered Personalization</li>
                        <li>Clean and Responsive Design</li>
                        <li>High-Quality Media Integration</li>
                        <li>Customizable Widgets and Modules</li>
                        <li>Dynamic Content Generation</li>
                        <li>Conversion-Optimized Landing Pages</li>
                        <li>Real-time Analytics and Insights</li>
                        <li>A/B Testing and Optimization</li>
                        <li>Smooth Checkout and Payment Process</li>
                        <li>Enhanced User Profiles</li>
                        <li>Interactive Product Showcases</li>
                        <li>Voice Search Integration</li>
                        <li>Gamification Elements for Engagement</li>
                        <li>Integrated CRM and Email Marketing</li>
                        <li>Robust Membership and Subscription System</li>
                        <li>Location-Based Services and Maps</li>
                        <li>Accelerated Mobile Pages (AMP)</li>
                        <li>Multi-channel Content Distribution</li>
                        <li>Automated Social Media Feeds</li>
                        <li>Interactive Quizzes and Polls</li>
                        <li>Predictive Product Recommendations</li>
                        <li>360-degree Product Views</li>
                        <li>Integration with E-commerce Platforms</li>
                        <li>Visual Storytelling Features</li>
                        <li>Virtual Events and Webinars</li>
                        <li>Rich Blogging and Content Management</li>
                        <li>Embedded Video Backgrounds</li>
                        <li>Premium Customer Support</li>
                        <li>Progressive Web App (PWA) Integration</li>
                        <li>AI-Enhanced Chatbot Support</li>
                        <li>Customizable Forms and Surveys</li>
                        <li>In-depth SEO Strategies</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="ppcdiscussion" style="display:none">
        <div class="fixed_scroll mt-3">
            <div class="row">
                <div class="col-sm-6">
                    <div class="whyus web5glist">
                        <h2 class="main_heading">Important Information to Know Before Selecting Google Ads Company</h2>
                        <div class="innerlist one">
                            <a class="webbtn" data-bs-toggle="collapse" href="#web2" role="button" aria-expanded="false" aria-controls="web2">
                            Understanding Your Business Objectives and Goals: <i class="fa fa-minus-circle"></i>
                            </a>
                            <div class="collapse show" id="web2">
                                <p>We'll start by understanding your business's primary objectives and specific goals for running Google Ads. This helps us tailor our strategies to align perfectly with your aspirations.</p>
                            </div>
                        </div>
                        <div class="innerlist">
                            <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web3" role="button" aria-expanded="false" aria-controls="web3">
                            Identifying Your Target Audience and Buyer Personas: <i class="fa fa-plus-circle"></i>
                            </a>
                            <div class="collapse" id="web3">
                                <p>Understanding who your target audience is and creating detailed buyer personas are essential steps in creating effective advertising campaigns. We will collaborate with you to identify your ideal customers and gather important information about them. This will help us design advertisements that truly connect with your potential customers and speak to their specific needs and preferences.</p>
                            </div>
                        </div>
                        <div class="innerlist">
                            <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web4" role="button" aria-expanded="false" aria-controls="web4">
                            Evaluating Your Website Readiness: <i class="fa fa-plus-circle"></i>
                            </a>
                            <div class="collapse" id="web4">
                                <p>We'll check your website's suitability for ads, suggest conversion-friendly improvements, and ensure a seamless user experience to boost desired actions and campaign success.</p>
                            </div>
                        </div>
                        <div class="innerlist">
                            <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web5" role="button" aria-expanded="false" aria-controls="web5">
                            Determining Your Budget Allocation: <i class="fa fa-plus-circle"></i>
                            </a>
                            <div class="collapse" id="web5">
                                <p>Budget management is a key aspect of running successful Google Ads campaigns. We'll discuss your budget and allocate it strategically across different campaigns and ad groups to maximize results.</p>
                            </div>
                        </div>
                        <div class="innerlist">
                            <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web6" role="button" aria-expanded="false" aria-controls="web6">
                            Addressing Advertising Risks: <i class="fa fa-plus-circle"></i>
                            </a>
                            <div class="collapse" id="web6">
                                <p>Every advertising campaign carries potential risks. Our focus is on identifying challenges like low conversions, dangerous competition, and unpredictable outcomes. We'll propose effective strategies to minimize these risks.</p>
                            </div>
                        </div>
                        <div class="innerlist">
                            <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web7" role="button" aria-expanded="false" aria-controls="web7">
                            Determining Your Budget Allocation: <i class="fa fa-plus-circle"></i>
                            </a>
                            <div class="collapse" id="web7">
                                <p>Budget management is a key aspect of running successful Google Ads campaigns. We'll discuss your budget and allocate it strategically across different campaigns and ad groups to maximize results.</p>
                            </div>
                        </div>
                        <div class="innerlist">
                            <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web8" role="button" aria-expanded="false" aria-controls="web8">
                            Exploring Advertising History Across Platforms, Locations, and Conversions: <i class="fa fa-plus-circle"></i>
                            </a>
                            <div class="collapse" id="web8">
                                <p>We'll review your past advertising experiences, looking into various platforms, geographical locations, and past conversion data. This historical analysis will provide valuable insights to guide our strategies for future success.</p>
                            </div>
                        </div>
                        <div class="innerlist">
                            <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web9" role="button" aria-expanded="false" aria-controls="web9">
                            Determining If Google Ads Fits Your Business: <i class="fa fa-plus-circle"></i>
                            </a>
                            <div class="collapse" id="web9">
                                <p>Let's analyze if Google Ads is the right fit for your business based on your profit margins with products or services. Although Many people use Google Ads, we need to check if it suits your goals and objectives.</p>
                            </div>
                        </div>
                        <div class="innerlist">
                            <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web10" role="button" aria-expanded="false" aria-controls="web10">
                            Assessing Risks of Running Ads and Budget Spending: <i class="fa fa-plus-circle"></i>
                            </a>
                            <div class="collapse" id="web10">
                                <p>Before we begin, let's talk about the potential risks involved in running Google Ads and investing your budget. It's important to be aware of challenges like low conversions, market competition, and unpredictable outcomes.</p>
                            </div>
                        </div>
                        <div class="innerlist">
                            <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web11" role="button" aria-expanded="false" aria-controls="web11">
                            Customer Lifetime Value (LTV) and Real Value of Conversions: <i class="fa fa-plus-circle"></i>
                            </a>
                            <div class="collapse" id="web11">
                                <p>We will explore the long-term value of your customers (LTV) and its connection to the actual value of conversions from advertising. This understanding guides us in making informed decisions and optimizing your budget wisely.</p>
                            </div>
                        </div>
                        <div class="innerlist">
                            <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web12" role="button" aria-expanded="false" aria-controls="web12">
                            Learning from Past Marketing Efforts: <i class="fa fa-plus-circle"></i>
                            </a>
                            <div class="collapse" id="web12">
                                <p>If you've engaged in marketing before, we'll review your past experiences to learn from what worked and what didn't. This way, we can fine-tune our approach and build on successful aspects.</p>
                            </div>
                        </div>
                        <div class="innerlist">
                            <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web13" role="button" aria-expanded="false" aria-controls="web13">
                            Addressing Your Concerns and Questions: <i class="fa fa-plus-circle"></i>
                            </a>
                            <div class="collapse" id="web13">
                                <p>We value open communication, so we'll provide ample time for you to ask any questions or express any concerns you may have about Google Ads and its management</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="whyus web5glist">
                            <h2 class="main_heading">How Personal Consultant Helps You For AAAA</h2>
                            <h4>(Unlocking the Full Benefits of Personal Consulting)</h4>
                            <div class="listpnl">
                                <div class="innerlist one">
                                    <a class="webbtn" data-bs-toggle="collapse" href="#web212" role="button" aria-expanded="false" aria-controls="web212">
                                    Educational Guidance: <i class="fa fa-minus-circle"></i>
                                    </a>
                                    <div class="collapse show" id="web212">
                                        <p>Our consultant provides educational consultation, explaining the basics of PPC advertising, its advantages, and how it can boost your business growth.</p>
                                    </div>
                                </div>
                                <div class="innerlist">
                                    <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web312" role="button" aria-expanded="false" aria-controls="web312">
                                    Confidence in Choice: <i class="fa fa-plus-circle"></i>
                                    </a>
                                    <div class="collapse" id="web312">
                                        <p>Our consultant is to ensure you feel confident in your decision, whether to start PPC or explore other marketing avenues.</p>
                                    </div>
                                </div>
                                <div class="innerlist">
                                    <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web412" role="button" aria-expanded="false" aria-controls="web412">
                                    Data Analysis: <i class="fa fa-plus-circle"></i>
                                    </a>
                                    <div class="collapse" id="web412">
                                        <p>Our consultant performs in-depth data analysis, examining your business's historical performance, market trends, and industry benchmarks to assess PPC feasibility.</p>
                                    </div>
                                </div>
                                <div class="innerlist">
                                    <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web512" role="button" aria-expanded="false" aria-controls="web512">
                                    Step-by-Step Support:  <i class="fa fa-plus-circle"></i>
                                    </a>
                                    <div class="collapse" id="web512">
                                        <p>Our consultant offers hands-on assistance, guiding you through the setup and management of PPC campaigns, ensuring a smooth and manageable process.</p>
                                    </div>
                                </div>
                                <div class="innerlist">
                                    <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web612" role="button" aria-expanded="false" aria-controls="web612">
                                    Platform Recommendations: <i class="fa fa-plus-circle"></i>
                                    </a>
                                    <div class="collapse" id="web612">
                                        <p>Guiding you in selecting the most suitable PPC platforms, considering your target audience and campaign objectives.</p>
                                    </div>
                                </div>
                                <div class="innerlist">
                                    <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web712" role="button" aria-expanded="false" aria-controls="web712">
                                    Existing Marketing Strategy:  <i class="fa fa-plus-circle"></i>
                                    </a>
                                    <div class="collapse" id="web712">
                                        <p>Our Consultant review your previous and current marketing efforts to identify how PPC can complement or enhance your overall strategy.</p>
                                </div>
                                <div class="innerlist">
                                    <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web812" role="button" aria-expanded="false" aria-controls="web812">
                                    Landing Page Optimization Recommendations: <i class="fa fa-plus-circle"></i>
                                    </a>
                                    <div class="collapse" id="web812">
                                        <p>Our consultant offers expert recommendations to optimize landing pages specifically for PPC campaigns. This ensures better user experiences and higher conversion rates, maximizing the effectiveness of your ads.</p>
                                    </div>
                                </div>
                                <div class="innerlist">
                                    <a class="webbtn collapsed" data-bs-toggle="collapse" href="#web912" role="button" aria-expanded="false" aria-controls="web912">
                                    Seasonal Campaign Planning: <i class="fa fa-plus-circle"></i>
                                    </a>
                                    <div class="collapse" id="web912">
                                        <p>Based on industry trends and data analysis, our consultant advises you on seasonal PPC campaign planning. This helps you capitalize on peak periods, while avoiding unnecessary expenses during slower times.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </div>
    <div id="packagelist" style="display:none">
        <div class="whyus">
            <h2 class="main_heading">Custom Package</h2>
            <h4>We offer Customized Web Design Packages and Pricing</h4>
            <div class="fixed_scroll custompackage">    
                <p class="text-center">Because, it totally depends on industry and personalized factors.</p>  
                <section class="about_us lightbrowm" >
                        <div class="provider_design mt-2">
                            <table class="table-striped w-100">
                                <tbody><tr>
                                    <th style="width:60%;background:#434242;" class="mobwidth">Web Design Pricing</th>
                                    <th style="width:13.3%" class="purple">5+ Pages </th>
                                    <th style="width:13.3%" class="green">10+ Pages</th>
                                    <th style="width:13.3%" class="brown">25+ Pages</th>
                                </tr>
                            </tbody></table>
                            <div id="tableprovider">
                                <button class="btn btn-primary">One Time Costing</button>
                                <div class="collapse show" id="collapseads" style="">
                                    <div class="table-responsive">
                                        <table class="table-striped w-100">
                                            <tbody>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Per Page Design Cost</td>
                                                <td style="width:13.3%; text-align:center" class="color1">₹900</i></td>
                                                <td style="width:13.3%; text-align:center" class="color2">₹700</td>
                                                <td style="width:13.3%; text-align:center" class="color3">₹500</td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Logo + Content + Graphic</td>
                                                <td style="width:13.3%; text-align:center" class="color1">₹2,500</i></td>
                                                <td style="width:13.3%; text-align:center" class="color2">₹4,500</td>
                                                <td style="width:13.3%; text-align:center" class="color3">₹5,500</td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Theme Selection (International Includes)</td>
                                                <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Inquiry Forms Setups</td>
                                                <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Webmail ID Setups</td>
                                                <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">In-Office Visit Allowed</td>
                                                <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Video Production</td>
                                                <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-times" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-times" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-times" aria-hidden="true"></i></td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Domain Support</td>
                                                <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Hosting Support</td>
                                                <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Mid & Top Level Designers Only</td>
                                                <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Fully Mobile Optimised</td>
                                                <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Tracking Optimised</td>
                                                <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-times" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-times" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-times" aria-hidden="true"></i></td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">On Page SEO</td>
                                                <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Payment Gateways  <small>(Paytm, PayPal, 25+ more)</small></td>
                                                <td style="width:13.3%; text-align:center" class="color1">₹3,000</td>
                                                <td style="width:13.3%; text-align:center" class="color2">₹3,000</td>
                                                <td style="width:13.3%; text-align:center" class="color3">₹3,000</td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Social Media Setup  <small>(FB, Insta, Linkedin, more 5+ platforms)</small></td>
                                                <td style="width:13.3%; text-align:center" class="color1">₹1,500</td>
                                                <td style="width:13.3%; text-align:center" class="color2">₹1,500</td>
                                                <td style="width:13.3%; text-align:center" class="color3">₹1,500</td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Live Chat Setup</td>
                                                <td style="width:13.3%; text-align:center" class="color1">₹1,500</td>
                                                <td style="width:13.3%; text-align:center" class="color2">₹1,500</td>
                                                <td style="width:13.3%; text-align:center" class="color3">₹1,500</td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">CRM Integration</td>
                                                <td style="width:13.3%; text-align:center" class="color1">₹1,500</td>
                                                <td style="width:13.3%; text-align:center" class="color2">₹1,500</td>
                                                <td style="width:13.3%; text-align:center" class="color3">₹1,500</td>
                                            </tr> 
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Google Map Creation (Pay After Approved by Google)</td>
                                                <td style="width:13.3%; text-align:center" class="color1">₹1,000</td>
                                                <td style="width:13.3%; text-align:center" class="color2">₹1,000</td>
                                                <td style="width:13.3%; text-align:center" class="color3">₹1,000</td>
                                            </tr> 
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Google Search Integration</td>
                                                <td style="width:13.3%; text-align:center" class="color1"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color2"><i class="fa fa-check" aria-hidden="true"></i></td>
                                                <td style="width:13.3%; text-align:center" class="color3"><i class="fa fa-check" aria-hidden="true"></i></td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Tech Team Involvement</td>
                                                <td style="width:13.3%; text-align:center" class="color1">2</td>
                                                <td style="width:13.3%; text-align:center" class="color2">2</td>
                                                <td style="width:13.3%; text-align:center" class="color3">2</td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Time Duration</td>
                                                <td style="width:13.3%; text-align:center" class="color1">3 Days</td>
                                                <td style="width:13.3%; text-align:center" class="color2">7 Days</td>
                                                <td style="width:13.3%; text-align:center" class="color3">15 Days</td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Our Support (Lifetime, Domain renewals every year.)</td>
                                                <td style="width:13.3%; text-align:center" class="color1">1 Year</td>
                                                <td style="width:13.3%; text-align:center" class="color2">1 Year</td>
                                                <td style="width:13.3%; text-align:center" class="color3">1 Year</td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Modification Support (in a month)</td>
                                                <td style="width:13.3%; text-align:center" class="color1">Once</td>
                                                <td style="width:13.3%; text-align:center" class="color2">Once</td>
                                                <td style="width:13.3%; text-align:center" class="color3">Twice</td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Copyright and Ownership</td>
                                                <td style="width:13.3%; text-align:center" class="color1">100%</td>
                                                <td style="width:13.3%; text-align:center" class="color2">100%</td>
                                                <td style="width:13.3%; text-align:center" class="color3">100%</td>
                                            </tr>    
                                            <tr>
                                                <td colspan="4"><b>NOTE:</b> WE NEVER CHARGE YOU ADDITIONAL OR HIDDEN FEES.</td>
                                            </tr>                             
                                        </tbody></table>
                                    </div>
                                </div> 
                                <button class="btn btn-primary">Yearly Renewal Costing</button>
                                <div class="collapse show" id="collapseads" style="">
                                    <div class="table-responsive">
                                        <table class="table-striped w-100">
                                            <tbody>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">.com Domain (Fixed) (From Godaddy/Bigrock)</td>
                                                <td style="width:13.3%; text-align:center" class="color1">₹399</i></td>
                                                <td style="width:13.3%; text-align:center" class="color2">₹399</td>
                                                <td style="width:13.3%; text-align:center" class="color3">₹399</td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Hosting Yearly (From Godaddy/Bigrock)</td>
                                                <td style="width:13.3%; text-align:center" class="color1">₹1,499</i></td>
                                                <td style="width:13.3%; text-align:center" class="color2">₹1,499</td>
                                                <td style="width:13.3%; text-align:center" class="color3">₹1,499</td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Https:// (SSL Certificates)  (From Godaddy/Bigrock)</td>
                                                <td style="width:13.3%; text-align:center" class="color1">₹999</td>
                                                <td style="width:13.3%; text-align:center" class="color2">₹999</td>
                                                <td style="width:13.3%; text-align:center" class="color3">₹999</td>
                                            </tr>
                                            <tr>
                                                <td style="width:60%" class="mobwidth">Web/Business Mail Id</td>
                                                <td style="width:13.3%; text-align:center" class="color1">₹100</td>
                                                <td style="width:13.3%; text-align:center" class="color2">₹100</td>
                                                <td style="width:13.3%; text-align:center" class="color2">₹100</td>
                                            </tr>                             
                                        </tbody></table>
                                    </div>
                                </div>   
                                <p style="padding:5px">At our company web5G technology private limited, we understand that every business has unique marketing goals. That's why we offer custom-designed and tailored website design packages specifically to help our clients achieve their objectives through effective websites.</p>            
                            </div>
                        </div>
                </section>  
            </div>
        </div>
    </div>    
       
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>    
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>   
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="js/jquery.serialscrolling.js"></script>
<script src="js/jquery.event.move.js"></script>
<script src="js/grouploop-1.0.0.min.js"></script>
<script src="js/swiper-bundle.min.js"></script>
<script src="js/jquery.ttpanel.js"></script>
<script src="js/javascript.js"></script>      
<script src="js/main.js"></script>      
<script src="js/webmain.js"></script>      
</body>
</html>