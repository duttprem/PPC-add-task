<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page | PPC 5G</title>
    <link rel="icon" type="image/x-icon" href="images/ppclogo.png">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet" >
    <link href="css/swiper-bundle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css" type="text/css"/>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N79T3LBF');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N79T3LBF"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->    <div class="progress-container">
        <div class="progress-bar" id="myBar"></div>
    </div>  
    <header class="lightbrowm">
        <div class="container">
            <div class="row">
                <div class="col-sm-2 logo">
                    <a href="index.php"><img src="images/ppclogo.png" /></a>
                </div>
                <div class="col-lg-6 col-md-9 col-sm-9">
                    <h1>Welcome to PPC5G.com</h1>
                    <p>Web5G Technology Pvt Ltd Redefines Success with Unmatched Google Ads & Advanced Tracking Mastery, with a strong presence in Delhi NCR.</p>
                </div>
                <div class="col-sm-12 col-lg-4 col-md-12">
                    <ul>
                        <li><a href="tel:9999123123"> <img alt="" src="images/phone.png" height="20px" width="20px"> 9999-123-123 (Info)</a></li>
                        <li><a href="tel:8588001122"><img alt="" src="images/phone.png" height="20px" width="20px"> 8588-001122 (PPC Support)</a></li>
                        <li><a href="tel:7777909090"><img alt="" src="images/phone.png" height="20px" width="20px"> 7777-909090 (Audit & Consultancy)</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header> 
    <div class="menu">
    <div class="container">
        <ul class="menulist">
            <li><a href="javascript:void(0);" class="menuicon" id="menushow"><i class="fa fa-bars" aria-hidden="true"></i> Menu</a></li>
        </ul>
        <a class="homeicon" href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a>
        <div class="clearfix"></div>
    </div>
<div class="menu childmenu">
        <div class="container">
            <ul class="firstmenu">
                <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal1">Why Us</a></li>
                <li><a href="#bookaduit" class="openModalBtn" data-modal-target="modal2">Book Aduit</a></li>
                <li><a href="javascript:void(0);" class="menudropdown">Checklist <i class="fa fa-angle-down" aria-hidden="true"></i></a> 
                    <ul class="submenu open1">
                        <!-- <div class="arrow-up"></div> -->
                        <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal3"><i class="fa fa-angle-right" aria-hidden="true"></i> Before Selecting PPC Company</a></li>
                        <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal4"><i class="fa fa-angle-right" aria-hidden="true"></i> Landing Page Mistakes</a></li>
                        <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal5"><i class="fa fa-angle-right" aria-hidden="true"></i> Discussion With PPC Experts</a></li>
                        <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal6"><i class="fa fa-angle-right" aria-hidden="true"></i> Personalized PPC Consultation</a></li>
                        <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal8"><i class="fa fa-angle-right" aria-hidden="true"></i> Reasons Why Clients Love Us?</a></li>
                        <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal9"><i class="fa fa-angle-right" aria-hidden="true"></i> Exclusive PPC Additional Services?</a></li>
                        <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal10"><i class="fa fa-angle-right" aria-hidden="true"></i> Types of ads we are expertise</a></li>
                    </ul>
                </li>
            </ul>
            <div class="clearfix"></div>
        </div>
    </div>    
</div>
</div>    <main class="landingpage">
        <section class="bgcontent">
            <div class="container">
                <h1>#1 LANDING PAGE EXPERTS</h1>
                <h4>Top-Ranked Landing Page Designing Professionals in Delhi NCR</h4>
                <p>Choose your handpicked package options with custom features checklist, priorities and action plan.</p>
            </div>
        </section>
        <section class="pad20 lightbrowm sectionone">
            <div class="container">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="box_inner">
                                <h2>Why Choose Us for Landing Page Designing Services</h2>
                                <div class="swiper mySwiper">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <ul>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> These landing pages are the deal-closers of your online ads or PPC campaigns. Each PPC ad campaign requires a specific landing page, tailored and tested to convert a strictly-defined group of visitors.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> The landing page is your first and best chance to turn a visitor from a PPC campaign into a customer. By using ppc5g.com services, you can experiment with different versions of your landing page as easily as different ad creatives in your PPC campaign.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> We consistently test to find the version that converts the most visitors, modifying PPC landing-page-designs to make sure you have one that’s tailored to your business.</li>
                                            </ul>
                                        </div>
                                        <div class="swiper-slide">
                                            <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Landing pages not only convert customers, they also indicate how well your marketing campaign is performing. By tracking how many conversions take place from the unique landing pages, you know if your Internet marketing campaign is a success or needs some adjusting.</li>
                                                <li><i class="fa fa-check" aria-hidden="true"></i> Unlike the other pages in your site, landing pages should not be indexable by search engines.</li>
                                            </ul>
                                        </div>                                  
                                    </div>
                                    <div class="swiper-button-next"></div>
                                    <div class="swiper-button-prev"></div>
                                    <div class="swiper-pagination"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 text-center">
                           <img src="images/topldgImg.webp" alt="" />
                        </div>
                        <div class="col-sm-4">
                            <div class="box_inner ">
                                <h2>LET US CONTACT YOU</h2>
                                <div class="details_form ">
                                    <form action="https://website5g.com/ppcmail.php" method="post" id="form1">
                                        <label>Enter Your Name <span style="color:red;">*</span></label>
                                        <div class="input-group mb-2">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><img src="images/user.png" alt="" /></span>
                                            </div>
                                            <input type="text" class="form-control" placeholder="Enter Your Name" name="name" required>
                                        </div>
                                        <label>Enter Your Email <span style="color:red;">*</span></label>
                                        <div class="input-group mb-2">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" ><img src="images/email.png" alt="" /></span>
                                            </div>
                                            <input type="email" name="email"  class="form-control" placeholder="Enter Your Email" required>
                                        </div>
                                        <label>Enter Your Number <span style="color:red;">*</span></label>
                                        <div class="input-group mb-2">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" ><img src="images/india-flag.png" alt="" /> &nbsp; +91</span>
                                            </div>
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel1" size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel2"  size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel3"  size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel4"  size="1" required >
                                            <input class="inputs one form-control mr1" type="tel" maxlength="1" placeholder="x"  name="tel5"  size="1" required >
                                            <input class="inputs one form-control ml1" type="tel" maxlength="1" placeholder="x"  name="tel6"  size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel7"  size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel8"  size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel9"  size="1" required >
                                            <input class="inputs one form-control" type="tel" maxlength="1" placeholder="x"  name="tel10"  size="1" required >
                                        </div>
                                        <label>Enter Your City <span style="color:red;">*</span></label>
                                        <div class="input-group mb-2">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><img src="images/map.png" alt="" /></span>
                                            </div>
                                            <input type="text" name="city" class="form-control" placeholder="Enter Your City" required>
                                        </div>
                                        <label>Enquiry About (Optional)</label>
                                        <div class="input-group mb-2">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><img src="images/enquiry.png" alt="" /></span>
                                            </div>
                                            <input type="text" name="message" class="form-control" placeholder="Enter your Enquiry">
                                        </div>
                                        <input type="submit" name="submit" class="form-control mb-2 btn btn-primary" value="Submit &amp; Get A Call Back ">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
        <div class="gapmob"></div>
        <section class="commonerror lightbrowm">
            <div class="container">
                <h2 class="main_heading">#15 Landing Page Mistakes by Popular Brands</h2>
                <div class="row pt-2 pb-2">
                    <div class="col-sm-12">
                        <div class="box_inner">
                            <h2>You're Wasting Over 90% of Your Advertising Budget If You Are Doing These Mistakes</h2>
                            <div class="swiper mySwiper">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #1</b> Your visitors don’t understand what you’re offering</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #2</b> Not using a fast hosting provider.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #3</b> Using a single conversion path</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #4</b> Too many conversion goals</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #5</b> Not using A/B testing or sometimes doing without enough data.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #6</b> Not thinking about landing page design for mobile screen size </li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #7</b> Assuming shorter forms convert better</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #8</b> Including a navigation menu and footer to distract visitor</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #9</b> Not matching ad copy with landing page copy</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #10</b> Not optimised for mobile.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #11</b> Forgetting your thank you page</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #12</b> Forgetting social proof, testimonials, Certifications, reviews & etc.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #13</b> Talking like a non-human, robot & without emotions etc.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #14</b> Your landing page is loading way too slowly</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Mistake #15</b> Showing more features than benefits</li>
                                        </ul>
                                    </div>                                   
                                </div>
                                <div class="swiper-button-next"></div>
                                <div class="swiper-button-prev"></div>
                                <div class="swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="gapmob"></div>
        <section class="commonerror lightgrey">
            <div class="container">
                <h2 class="main_heading">TYPES OF CUSTOM BUSINESS BASED LANDING PAGES</h2>
                <p class="text-center">We offer personalized landing page design services, taking into account industry-specific and competitive factors.</p>
                <div class="row pt-2 pb-2">
                    <div class="col-sm-12">
                        <div class="box_inner">
                            <div class="swiper mySwiper">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Custom Lead Magnet Landing Page:</b> Our custom design experts offer advanced landing page design services for all types of businesses, using the latest technology for tracking goals, conversions, leads, and more.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Conversion-Driven Landing Pages:</b> These pages are designed strategically with the main goal of increasing the number of people who take desired actions, such as making a purchase or signing up for a service.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>E-commerce Landing Page Design:</b> These pages are created to be interesting and appealing to customers, with the aim of encouraging them to buy products online and help businesses make more money.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Real Estate Landing Page Solutions:</b> These pages are made to look attractive and showcase properties in the best way possible, aiming to attract potential clients who are interested in buying or renting real estate.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Health and Wellness Landing Pages:</b> These pages provide useful and easy-to-understand information about healthcare services, making them inviting to visitors who may be seeking medical assistance or advice.</li>
                                        </ul>
                                    </div> 
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>VIP Access Landing Page</b> A landing page offering VIP access or early-bird registration for a limited-capacity event, membership, or product release, creating a sense of exclusivity and urgency.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Product Comparison Landing Page:</b> A landing page that presents a side-by-side comparison of different product options, helping visitors make an informed decision and capturing lead information for further follow-up.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Lead Nurture Landing Page:</b> A landing page designed specifically for nurturing leads at different stages of the customer journey, providing tailored content and offers based on their level of engagement and readiness to convert.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Product Demo Landing Page:</b> A landing page offering a product demonstration or walkthrough video, showcasing the features and functionalities to generate leads interested in learning more and making a purchase decision.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Consultation Request Landing Page:</b> A landing page focused on offering a consultation or assessment session, encouraging visitors to provide their contact details to schedule a one-on-one discussion with an expert.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Product Launch Landing Page:</b> A landing page created to generate buzz and capture leads for a new product or service launch, leveraging enticing visuals, compelling messaging, and a call-to-action to gather contact information.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> <b>Event Registration Landing Page:</b> A landing page dedicated to promoting and registering attendees for a specific event, such as a conference, workshop, or networking session, gathering lead details for further communication.</li>
                                        </ul>
                                    </div>                                      
                                </div>
                                <div class="swiper-button-next"></div>
                                <div class="swiper-button-prev"></div>
                                <div class="swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="gapmob"></div>
        <section class="commonerror lightbrowm">
            <div class="container">
                <h2 class="main_heading">Additional Benefits in  Our Landing Page Design</h2>
                <p class="text-center">Encourage Urgency and Scarcity: Tell people that they need to act quickly because there's only a limited time or a limited number available.</p>
                <div class="row pt-2 pb-2">
                    <div class="col-sm-12">
                        <div class="box_inner">
                            <div class="swiper mySwiper">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Mobile-First Design Approach: Prioritize designing for mobile devices to ensure a seamless experience for the majority of users.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Relevant and High-Quality Imagery: Use pictures and videos that people like and that go well with your message.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Error-Free User Experience:Make sure everything works perfectly on your website, like buttons and forms, so people don't have any problems.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Highlight Benefits Over Features: Explain clearly how your product or service helps people and solves their problems.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integrate User Generated Content:Show what people who use your product or service say about it, like their reviews or stories. This helps others trust your product.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Consistent Branding Elements:Keep the colors, writing style, and pictures the same across all your stuff to make it look neat and professional.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Simplify Navigation:Make it easy for people to go where they want on your website.</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Content Personalization Using Cookies:Show things that match what people like based on what they did before on your website, using cookie data.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Strategic Copywriting: Craft compelling and concise copy that communicates value proposition and encourages action.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Visual Hierarchy Design: Implement a clear visual hierarchy to guide users' attention towards key conversion elements.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Loading Speed Optimization: Optimize landing page loading speed to reduce bounce rates and improve user experience.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> A/B Testing for Iterative Improvement: Conduct continuous A/B tests to optimize various elements and enhance conversion rates.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Whitespace Utilization: Use whitespace effectively to enhance readability and focus on key elements.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Localized Content for Personalization: Tailor content based on location or language preferences to connect with a diverse audience.</li>
                                        </ul>
                                    </div>
                                    <div class="swiper-slide">
                                        <ul>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Progressive Disclosure Forms: Utilize progressive forms that gradually collect information, reducing friction and increasing form completions.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Security and Trust Badges: Display trust symbols, security certificates, or client logos to enhance credibility and build trust.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Personalization Based on Behavior: Customize landing page elements based on users' past interactions and behaviors for a personalized experience.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> SEO Optimization for Visibility: Optimize landing page content for relevant keywords and improve its ranking on search engine results.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Integrate Chat Support for Instant Help: Implement live chat support or chatbots to provide immediate assistance and answer queries.</li>
                                            <li><i class="fa fa-check" aria-hidden="true"></i> Content Scannability and Readability: Organize content in a scannable format with bullet points, headings, and short paragraphs to enhance readability.</li>
                                        </ul>
                                    </div>                                   
                                </div>
                                <div class="swiper-button-next"></div>
                                <div class="swiper-button-prev"></div>
                                <div class="swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>       
        <div class="gapmob"></div>        
    </main> 
    <footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 footerfirst">
                <h3>Connect with Our Team</h3>
                <h5>General Inquiries</h5>
                <ul>
                    <li><a href="tel:9999123123"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 9999-123-123</a></li>
                    <li><a href="mailto:info@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: info@ppc5g.com</a></li>
                </ul>
                <h5>PPC Support Team</h5>
                <ul>
                    <li><a href="tel:8588001122"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 8588-001122</a></li>
                    <li><a href="mailto:support@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: support@ppc5g.com</a></li>
                </ul>
                <h5>PPC Audit & Consultancy</h5>
                <ul>
                    <li><a href="tel:7777909090"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 7777-909090</a></li>
                    <li><a href="mailto:audit@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: audit@ppc5g.com</a></li>
                </ul>
            </div>
            <div class="col-sm-4 footerfirst">
                <h3>Contact with Us</h3>
                <ul>
                <li><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 626, 6th Floor, Signature Global Mall,<br>Sector-3, Vaishali, Ghaziabad,<br> Uttar Pradesh-201010</a></li>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.4736342932583!2d77.3329667742235!3d28.645533783492468!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x64662107506a59b3%3A0x1952eb50974829ec!2sWeb5G%20Technology%20Private%20Limited!5e0!3m2!1sen!2sin!4v1695913605459!5m2!1sen!2sin" width="100%" height="220" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </ul>
            </div>
        </div>
    </div>
    <div class="copyright">
        <p>© 2023 PPC5G Technology Pvt. Ltd. All Right Reserved.</p>
    </div>
</footer>  <div class="landingactive">  
    <div class="menu_overlay">
    <div id="menuopen" class="menuslide">
        <img src="images/ppclogo.png" alt="" />
        <span class="comtitle">Web5G Technology Pvt. Ltd</span>
        <button id="menuclose"><i class="fa fa-times" aria-hidden="true"></i>   </button>
        <div class="menu_body">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="ppc-services.php">Google Ads Services</a></li>
                <li><a href="landing-page.php">Landing Page Design Services</a></li>
                <li><a href="website-design.php">Website Design Services</a></li>
                <li><a href="javascript:void(0);" class="slidedownmenu">About Us<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                    <ul class="slidemenu">
                        <li><a href="about-us.php">About Us</a></li>
                        <li><a href="about-director.php">About Director</a></li>
                    </ul>
                </li>
                <li><a href="legal.php">Legal</a></li>
                <li><a href="privacy-policy.php">Privacy Policy</a></li>
            </ul>
        </div>
    </div>
</div></div>
       
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>    
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/swiper-bundle.min.js"></script>
<script src="js/commonjs.js"></script>
</body>
</html>